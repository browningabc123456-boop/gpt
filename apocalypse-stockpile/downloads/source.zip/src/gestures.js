// Shared screen-space camera math: the same gestures work at every viewport size.
export function wrappedAngle(angle){return Math.atan2(Math.sin(angle),Math.cos(angle));}
export function clampCameraTarget(target){target.x=Math.max(-60,Math.min(60,target.x));target.y=Math.max(.08,Math.min(18,target.y));target.z=Math.max(-52,Math.min(52,target.z));}
export function panCamera(target,dx,dy,radius,yaw,pitch,height){const scale=2*radius*Math.tan(43*Math.PI/360)/Math.max(80,height);const c=Math.cos(yaw),s=Math.sin(yaw),sp=Math.sin(pitch),cp=Math.cos(pitch);target.x+=(-dx*c-dy*s*sp)*scale;target.y+=dy*cp*scale;target.z+=(dx*s-dy*c*sp)*scale;clampCameraTarget(target);}
export function touchPair(points){const [a,b]=points;return{distance:Math.max(8,Math.hypot(a.x-b.x,a.y-b.y)),angle:Math.atan2(b.y-a.y,b.x-a.x),x:(a.x+b.x)/2,y:(a.y+b.y)/2};}
