import * as T from 'three';import {RoundedBoxGeometry} from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';import {artUV} from './art.js';import {itemSize} from './sizes.js';import {mergeGeometries} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
const material=new T.MeshStandardMaterial({vertexColors:true,roughness:1,metalness:1});const glassMaterial=new T.MeshStandardMaterial({vertexColors:true,transparent:true,opacity:.28,roughness:.12,metalness:0,depthWrite:false,side:T.DoubleSide});const cache=new Map();
export function itemGeometry(p){if(cache.has(p.id))return cache.get(p.id);let parts=[],surfaceOverride=null;const C=p.color,cream='#f0e8d6',steel='#bdc7c5',dark='#31534a',brown='#a77b4e';
function add(g,c,x=0,y=0,z=0,rx=0,ry=0,rz=0,sx=1,sy=1,sz=1){if(g.index){const old=g;g=g.toNonIndexed();old.dispose();}artUV(g,surfaceOverride==='label'?'paper':surfaceOverride||(c===steel?'metal':['保暖露营','粮油主食'].includes(p.cat)?'fabric':['炊具生活'].includes(p.cat)?'ceramic':'plastic'),surfaceOverride==='label'?p:null);g.userData.glass=surfaceOverride==='glass';g.applyMatrix4(new T.Matrix4().compose(new T.Vector3(x,y,z),new T.Quaternion().setFromEuler(new T.Euler(rx,ry,rz)),new T.Vector3(sx,sy,sz)));const col=new T.Color(c),a=new Float32Array(g.attributes.position.count*3);for(let i=0;i<a.length;i+=3){a[i]=col.r;a[i+1]=col.g;a[i+2]=col.b;}g.setAttribute('color',new T.BufferAttribute(a,3));parts.push(g);}
const box=(w,h,d,c,x=0,y=h/2,z=0,rz=0)=>add((Math.min(w,h,d)>.075?new RoundedBoxGeometry(w,h,d,1,Math.min(.025,w/8,h/8,d/8)):new T.BoxGeometry(w,h,d)),c,x,y,z,0,0,rz);
const cyl=(r,h,c,x=0,y=h/2,z=0,rt=r)=>add(new T.CylinderGeometry(rt,r,h,20),c,x,y,z);
const ball=(x,y,z,sx,sy,sz,c)=>add(new T.SphereGeometry(1,16,10),c,x,y,z,0,0,0,sx,sy,sz);
const ring=(r,t,c,x,y,z,rx=0,ry=0,rz=0)=>add(new T.TorusGeometry(r,t,6,18),c,x,y,z,rx,ry,rz);
const stem=(x,y,z,h,c=dark)=>cyl(.018,h,c,x,y+h/2,z);
function label(g,x=0,y=0,z=0,rx=0,ry=0,rz=0){surfaceOverride='label';add(g,'#ffffff',x,y,z,rx,ry,rz);surfaceOverride=null;}
function glass(g,c,x=0,y=0,z=0,rx=0,ry=0,rz=0){surfaceOverride='glass';add(g,c,x,y,z,rx,ry,rz);surfaceOverride=null;}
function lathe(profile,c,x=0,y=0,z=0){add(new T.LatheGeometry(profile.map(([r,y])=>new T.Vector2(r,y)),24),c,x,y,z);}
function bottle(type){
 const wide=type==='jug'||type==='oil',r=wide?.26:.18,h=type==='coffee'?.48:.63,cap=['cola','coffee'].includes(type)?'#374b3a':type==='juice'?'#dc9743':'#31534a';
 const profile=[[0,.01],[r*.75,.01],[r,.04],[r,h*.82],[r*.93,h],[.075,h+.12],[.07,h+.2],[0,h+.2]];
 const liquid=['water','jug'].includes(type)?'#b5d9d4':type==='coffee'?'#4b3023':type==='tea'?'#996436':type==='cola'?'#472c22':C;
 lathe(profile.map(([a,b])=>[a*.88,b*.96]),liquid);
 glass(new T.LatheGeometry(profile.map(([a,b])=>new T.Vector2(a,b)),24),'#d5ece3');
 cyl(.081,.10,cap,0,h+.2);for(let i=0;i<14;i++){const a=i/14*Math.PI*2;box(.008,.076,.009,'#55745b',Math.sin(a)*.083,h+.2,Math.cos(a)*.083);}
 if(['water','jug'].includes(type))for(let y=.11;y<h*.95;y+=.095)ring(r,.006,'#c6dfd9',0,y,0,Math.PI/2);
 label(new T.CylinderGeometry(r+.005,r+.005,h*.33,32,1,true),0,h*.47,0,0,Math.PI*.55);
 if(wide){ring(.14,.035,cap,.22,h+.01,0,0,Math.PI/2);cyl(r*.94,.025,cap,0,.03);}
 if(type==='sport'){cyl(.09,.05,cream,0,h+.28);cyl(.045,.05,'#d9a65b',0,h+.33);}
}
function can(flat=false){const h=flat?.23:.65,r=flat?.29:.24;cyl(r,h,C);cyl(r+.01,.025,steel,0,h,0);cyl(r+.01,.02,steel,0,.02,0);ring(.055,.011,dark,.06,h+.02,0,Math.PI/2);label(new T.CylinderGeometry(r+.012,r+.012,h*.68,32,1,true),0,h*.48,0,0,Math.PI*.55);if(!flat){for(let i=0;i<3;i++)ball((i-1)*.07,.33,.245,.035,.05,.012,p.id==='corn'?'#ad9c4c':'#ac6846');}}
function sack(flour=false){ball(0,.34,0,.29,.35,.21,C);box(.34,.07,.24,brown,0,.68);for(let i=-2;i<=2;i++)box(.008,.05,.01,cream,i*.055,.68,.125);if(flour){box(.28,.18,.015,'#c28c67',0,.34,.205);for(let i=0;i<5;i++)box(.012,.15,.015,cream,-.07+i*.035,.35,.218,-.15);}else{ball(0,.35,.209,.11,.13,.015,p.id==='lentil'?'#9f6656':'#b3b377');for(let i=0;i<6;i++)ball((i%3-1)*.04,.28+Math.floor(i/3)*.09,.23,.012,.025,.008,cream);}}
function jar(type){const h=type==='jam'?.4:.62;const inside=type==='pickle'?'#a8b97b':type==='honey'?'#cc933b':C;
 cyl(.215,h-.04,inside,0,h/2,0);glass(new T.CylinderGeometry(.245,.245,h,24),'#dfede2',0,h/2);cyl(.253,.055,type==='pickle'?'#31534a':steel,0,h+.03);
 for(let i=0;i<12;i++){const a=i*Math.PI/6;box(.015,.045,.015,'#9caa9b',Math.sin(a)*.25,h+.03,Math.cos(a)*.25);}
 if(type==='pickle')for(let i=-1;i<=1;i++)ball(i*.12,.32,.19,.045,.2,.038,'#607d3f');
 if(type==='fruitjar')for(let i=0;i<3;i++)ball((i-1)*.11,.24+(i%2)*.15,.17,.09,.12,.06,'#efbc55');
 label(new T.PlaneGeometry(.38,h*.48),0,h*.44,.251);
}
function toolHandle(h=.65){box(.09,h,.08,brown,0,h/2+.05);}
switch(p.shape){
case 'water':case 'jug':case 'soda':case 'cola':case 'tea':case 'juice':case 'coffee':case 'sport':case 'oil':bottle(p.shape);break;
case 'milk':case 'carton':{box(.4,.65,.36,C);const roof=new T.CylinderGeometry(.28,.28,.38,3);add(roof,C,0,.75,0,Math.PI/2,0,Math.PI/2);box(.05,.05,.35,cream,0,.92);box(.4,.15,.367,p.shape==='milk'?'#7eabbf':'#8eaa6c',0,.2);for(let i=0;i<3;i++)ball((i-1)*.08,.48,.183,.04,.03,.008,p.shape==='milk'?cream:'#bbce9f');break;}
case 'sack':case 'flour':sack(p.shape==='flour');break;
case 'can':case 'tin':case 'oats':case 'flatcan':can(p.shape==='flatcan');break;
case 'sardine':case 'spam':{box(.56,.23,.37,C);box(.58,.025,.39,steel,0,.25);ring(.05,.01,dark,.12,.27,0,Math.PI/2);if(p.shape==='sardine'){ball(0,.12,.19,.16,.045,.008,cream);}break;}
case 'fruitjar':case 'pickle':case 'jam':case 'honey':case 'coffeejar':jar(p.shape);break;
case 'noodlecup':{add(new T.CylinderGeometry(.29,.21,.55,16),C,0,.275);cyl(.3,.025,cream,0,.56);for(let i=0;i<5;i++)box(.015,.13,.015,'#e4cf8a',-.09+i*.045,.25,.268,.15);break;}
case 'packet':case 'cracker':case 'dumpling':case 'petfood':{ball(0,.28,0,.3,.29,.19,C);box(.48,.04,.14,cream,0,.56);box(.48,.04,.14,cream,0,.025);if(p.shape==='packet'){ball(0,.28,.18,.16,.11,.025,'#e9c778');for(let i=0;i<4;i++)box(.22,.012,.01,'#b68b4c',0,.24+i*.03,.21);}else if(p.shape==='petfood'){ball(0,.3,.18,.1,.08,.02,cream);for(let i=-1;i<=1;i++)ball(i*.07,.41,.18,.033,.04,.02,cream);}else if(p.shape==='dumpling'){for(let i=-1;i<=1;i++)ball(i*.12,.3,.16,.065,.045,.04,cream);}break;}
case 'pasta':{box(.28,.83,.19,C);box(.2,.6,.015,'#dec77b',0,.45,.1);for(let i=-3;i<=3;i++)box(.012,.56,.018,'#ac8c43',i*.025,.45,.115);box(.29,.12,.2,'#a35f49',0,.13);break;}
case 'bread':{ball(0,.24,0,.3,.24,.19,C);for(let i=-2;i<=2;i++){box(.02,.2,.33,'#e0b87c',i*.09,.32,0,-.2);}break;}
case 'salt':cyl(.16,.46,cream);cyl(.17,.06,steel,0,.49);for(let i=-1;i<=1;i++)ball(i*.05,.525,0,.015,.006,.015,dark);break;
case 'sauce':case 'soy':{bottle('coffee');cyl(.06,.2,p.shape==='sauce'?'#9c4437':'#b29b71',0,.8);break;}
case 'apple':case 'orange':case 'tomato':{ball(-.065,.23,0,.22,.23,.23,C);ball(.065,.23,0,.22,.23,.23,C);stem(0,.4,0,.1,brown);if(p.shape==='tomato')for(let i=0;i<5;i++)ball(Math.sin(i*1.25)*.09,.43,Math.cos(i*1.25)*.09,.035,.015,.09,'#748e4f');break;}
case 'banana':{for(let i=0;i<4;i++){add(new T.TorusGeometry(.19,.055,7,14,Math.PI*.8),C,-.12+i*.075,.21+i*.025,0,0,.5,1.2);box(.04,.07,.05,brown,-.23+i*.075,.41+i*.025,0);}break;}
case 'carrot':{add(new T.ConeGeometry(.12,.56,12),C,0,.27,0,0,0,Math.PI);for(let i=-1;i<=1;i++)ball(i*.05,.63,0,.025,.15,.025,'#7c9d60');break;}
case 'cabbage':{ball(0,.25,0,.3,.26,.27,C);for(let i=0;i<7;i++)ball(Math.sin(i*2)*.2,.25+Math.cos(i)*.08,Math.cos(i*2)*.2,.13,.2,.08,i%2?'#aec28d':'#83a364');break;}
case 'potato':{for(let i=0;i<3;i++){ball((i-1)*.16,.13+(i%2)*.1,0,.17,.13,.12,C);ball((i-1)*.16+.06,.17+(i%2)*.1,.1,.012,.012,.012,brown);}break;}
case 'eggs':{box(.62,.06,.46,'#bcaf92');for(let i=0;i<6;i++)ball((i%3-1)*.19,.16,Math.floor(i/3)*.21-.105,.08,.12,.08,cream);break;}
case 'cheese':{add(new T.CylinderGeometry(.3,.3,.3,3),C,0,.15);for(let i=0;i<3;i++)ball((i-1)*.09,.17,.16,.035,.03,.015,'#c3a24c');break;}
case 'meat':{box(.65,.06,.44,cream);for(let i=-1;i<=1;i++){ball(i*.17,.12,0,.14,.07,.16,C);ball(i*.17,.16,0,.09,.015,.1,'#dfb3a0');}break;}
case 'fish':{ball(0,.2,0,.3,.1,.11,C);add(new T.ConeGeometry(.13,.17,3),C,-.3,.2,0,0,0,Math.PI/2);ball(.19,.23,.09,.018,.018,.018,dark);break;}
case 'medkit':case 'toolbox':{box(.6,.38,.31,C,0,.23);box(.62,.1,.33,p.shape==='toolbox'?'#7b8a6b':cream,0,.45);ring(.11,.035,dark,0,.52,0);for(let x of [-.2,.2])box(.045,.1,.03,steel,x,.4,.18);if(p.shape==='medkit'){box(.06,.21,.02,'#b8584b',0,.25,.17);box(.21,.06,.02,'#b8584b',0,.25,.17);}break;}
case 'bandage':case 'roll':case 'tape':{const r=p.shape==='roll'?.25:.2;ring(r,r*.44,C,0,r*1.4,0,0,Math.PI/2);ring(r*.3,.03,brown,.13,r*1.4,0,0,Math.PI/2);break;}
case 'pills':case 'alcohol':case 'seed':{cyl(.18,.4,C);cyl(.19,.09,p.shape==='alcohol'?'#86ab94':cream,0,.45);if(p.shape==='pills'){box(.07,.18,.015,'#b87565',0,.21,.18);box(.18,.06,.015,'#b87565',0,.21,.18);}else if(p.shape==='seed')for(let i=0;i<4;i++)ball((i-1.5)*.05,.2,.17,.016,.04,.01,'#72874d');break;}
case 'blister':{box(.37,.05,.59,steel);for(let x of [-.1,.1])for(let z of [-.19,0,.19])ball(x,.06,z,.065,.04,.08,cream);break;}
case 'mask':{box(.5,.24,.08,C,0,.16);for(let i=0;i<3;i++)box(.45,.012,.02,'#8bb2b7',0,.1+i*.06,.052);for(let x of [-.3,.3])ring(.09,.012,cream,x,.17,0);break;}
case 'socks':{for(let side of [-1,1]){box(.19,.39,.07,C,side*.12,.29);ball(side*.12,.1,.06,.10,.09,.13,C);for(let y=.43;y<.49;y+=.025)box(.2,.009,.075,'#eee5ce',side*.12,y);}break;}
case 'gloves':{if(p.id==='gloveswarm'){for(let side of [-1,1]){ball(side*.14,.28,0,.12,.21,.06,C);ball(side*.28,.23,0,.055,.12,.055,C);box(.2,.07,.1,cream,side*.14,.06);for(let x=-2;x<=2;x++)box(.009,.28,.012,'#cdbda0',side*.14+x*.035,.26,.06);}break;}for(let side of [-1,1]){ball(side*.14,.24,0,.11,.2,.06,C);for(let i=0;i<4;i++)box(.035,.18,.09,C,side*.14+(i-1.5)*.042,.47);box(.06,.18,.08,C,side*.27,.27,0,-side*.4);}break;}
case 'thermo':case 'brush':{box(.08,.75,.06,cream);if(p.shape==='thermo'){box(.06,.2,.015,'#859b91',0,.5,.04);}else{box(.16,.22,.09,C,0,.7);for(let i=0;i<4;i++)box(.13,.025,.05,cream,0,.62+i*.05,.06);}break;}
case 'goggle':{for(let x of [-.15,.15]){ring(.12,.025,dark,x,.22,0);ball(x,.22,0,.1,.09,.02,C);}box(.09,.025,.03,dark,0,.23);break;}
case 'respirator':{ball(0,.32,0,.22,.27,.16,dark);for(let x of [-.13,.13])ball(x,.4,.15,.09,.1,.025,C);cyl(.1,.14,steel,0,.1,.15);break;}
case 'tissue':{box(.55,.24,.35,C);ball(0,.26,0,.17,.025,.06,dark);box(.19,.2,.025,cream,0,.34,0,.15);break;}
case 'soap':case 'sponge':{box(.42,.13,.27,C);box(.42,.04,.27,p.shape==='sponge'?'#7f946a':'#dfc5b0',0,.15);break;}
case 'pump':case 'detergent':{ball(0,.3,0,.23,.3,.15,C);cyl(.07,.12,dark,0,.62);box(.28,.06,.07,cream,.07,.72);if(p.shape==='detergent')ring(.12,.03,cream,.18,.48,0,0,Math.PI/2);break;}
case 'tube':{add(new T.CylinderGeometry(.11,.15,.55,4),C,0,.34);box(.23,.035,.16,cream,0,.63);cyl(.1,.08,cream,0,.055);break;}
case 'towel':case 'blanket':{if(p.shape==='towel'){for(let i=0;i<3;i++)box(.53,.08,.36,i%2?cream:C,0,.055+i*.08);}else{ring(.18,.07,C,0,.24,0,0,Math.PI/2);box(.5,.04,.34,brown,0,.24);}break;}
case 'trash':case 'mat':case 'tent':{add(new T.CylinderGeometry(.16,.16,.6,12),C,0,.18,0,0,0,Math.PI/2);for(let x of [-.2,.2])ring(.165,.02,brown,x,.18,0,0,Math.PI/2);break;}
case 'bucket':{add(new T.CylinderGeometry(.27,.2,.42,16,1,true),C,0,.22);cyl(.2,.02,C,0,.02);ring(.27,.015,steel,0,.46,0,0,0);break;}
case 'flashlight':{cyl(.11,.5,dark);cyl(.19,.16,C,0,.56);cyl(.16,.025,'#e5d5a0',0,.66);box(.06,.1,.03,C,0,.25,.11);break;}
case 'lantern':{cyl(.24,.08,C,0,.07);cyl(.16,.4,'#e9d9a8',0,.32);cyl(.24,.08,C,0,.57);for(let x of [-.19,.19])box(.03,.5,.03,dark,x,.33);ring(.15,.025,dark,0,.75,0);break;}
case 'candle':{cyl(.16,.4,C);stem(0,.4,0,.05,brown);ball(0,.49,0,.045,.08,.035,'#d4b365');break;}
case 'batteries':{for(let z of[-.1,.1])for(let x of [-.15,.15]){cyl(.09,.4,dark,x,.2,z);cyl(.095,.12,'#b9ac72',x,.32,z);cyl(.035,.025,steel,x,.42,z);}break;}
case 'powerbank':case 'bento':{box(.5,.13,.3,C);box(.51,.025,.31,cream,0,.145);for(let x of [-.12,0,.12])box(.055,.025,.02,dark,x,.08,.16);break;}
case 'solar':{box(.6,.045,.65,dark);for(let x of [-.15,.15])for(let z of [-.22,0,.22])box(.25,.012,.18,C,x,.055,z);break;}
case 'generator':{box(.46,.3,.38,C,0,.24);for(let x of [-.29,.29]){box(.045,.56,.045,dark,x,.3,-.23);box(.045,.56,.045,dark,x,.3,.23);box(.045,.045,.5,dark,x,.58);}cyl(.11,.25,steel,.17,.55);for(let i=0;i<4;i++)box(.1,.018,.03,dark,-.12,.18+i*.05,.2);break;}
case 'gas':case 'extinguisher':{cyl(.2,.54,C,0,.32);ball(0,.6,0,.2,.14,.2,C);cyl(.055,.1,steel,0,.77);box(.26,.045,.09,dark,.04,.83);if(p.shape==='extinguisher'){box(.04,.4,.04,dark,.23,.55);box(.21,.06,.04,dark,.16,.77);box(.16,.2,.02,cream,0,.34,.205);}break;}
case 'matches':case 'book':{box(.4,p.shape==='book'?.65:.13,.25,C);box(.35,p.shape==='book'?.59:.08,.255,cream,.02,p.shape==='book'?.32:.075);box(.04,p.shape==='book'?.65:.13,.26,C,-.18);if(p.shape==='book')box(.16,.13,.018,'#6f855b',.03,.45,.14);break;}
case 'radio':case 'walkie':{box(p.shape==='radio'?.57:.28,.46,.22,C);for(let i=0;i<4;i++)box(.2,.018,.02,dark,-.08,.15+i*.055,.12);for(let x of [.13,.23])cyl(.035,.025,cream,x,.49);box(.015,.42,.015,steel,-.12,.67);if(p.shape==='walkie')box(.18,.1,.02,dark,0,.34,.12);break;}
case 'cable':case 'rope':{for(let i=0;i<4;i++)ring(.19,.025,C,0,.045+i*.045,0,Math.PI/2);if(p.shape==='cable')box(.08,.11,.05,dark,.19,.13,.16);break;}
case 'hammer':case 'axe':case 'shovel':case 'knife':{toolHandle();if(p.shape==='hammer'){box(.39,.15,.16,steel,-.03,.73);for(let z of[-.065,.065])box(.18,.06,.04,steel,.23,.79,z,-.3);}if(p.shape==='axe')add(new T.CylinderGeometry(.2,.3,.09,3),steel,.12,.68,0,Math.PI/2,0,.5);if(p.shape==='shovel')ball(0,.7,0,.2,.21,.035,steel);if(p.shape==='knife')box(.12,.46,.025,steel,0,.6);break;}
case 'wrench':{box(.09,.53,.045,steel,0,.3);box(.24,.09,.08,steel,0,.6);box(.08,.19,.08,steel,-.11,.69);box(.09,.13,.08,steel,.1,.69);cyl(.045,.07,dark,0,.55);ring(.05,.018,steel,0,.08,0);break;}
case 'lock':{box(.3,.27,.12,C);ring(.105,.025,steel,0,.36,0);box(.025,.08,.02,dark,0,.13,.07);break;}
case 'scissors':{for(let x of [-.1,.1]){ring(.07,.025,C,x,.13,0);box(.035,.49,.03,steel,x*.3,.4,0,x>0?-.25:.25);}break;}
case 'compass':{cyl(.25,.09,C);add(new T.ConeGeometry(.045,.25,3),'#b76b56',0,.095,-.05,Math.PI/2);break;}
case 'sleepingbag':{ball(0,.25,0,.22,.25,.33,C);for(let z of [-.17,.17])box(.45,.04,.055,brown,0,.24,z);break;}
case 'backpack':{ball(0,.38,0,.25,.36,.16,C);box(.33,.21,.12,'#7e8f68',0,.22,.18);for(let x of [-.15,.15])box(.04,.5,.03,brown,x,.38,.17);ring(.09,.025,dark,0,.77,0);break;}
case 'boots':{for(let x of [-.15,.15]){box(.22,.4,.23,C,x,.25);ball(x,.12,.1,.12,.1,.2,C);box(.24,.04,.44,dark,x,.04,.08);}break;}
case 'coat':{ball(0,.72,-.02,.18,.15,.12,C);box(.34,.6,.14,C,0,.35);for(let y=.15;y<.6;y+=.09)box(.32,.009,.147,'#8b8064',0,y);for(let x of[-.1,.1])box(.08,.09,.025,dark,x,.24,.085);for(let x of [-.25,.25])box(.13,.5,.14,C,x,.4,0,x>0?.3:-.3);box(.015,.55,.02,steel,0,.35,.08);break;}
case 'hotwater':{ball(0,.3,0,.23,.3,.09,C);cyl(.05,.1,cream,0,.65);for(let i=-2;i<=2;i++)box(.015,.3,.01,'#d1a999',i*.065,.3,.09);break;}
case 'pot':case 'bowl':case 'mug':case 'kettle':{const r=p.shape==='mug'?.18:.27,h=p.shape==='bowl'?.22:.35;
 lathe([[0,.015],[r*.68,.015],[r*.85,.04],[r,h],[r-.022,h],[r*.8,.055],[0,.055]],p.shape==='pot'||p.shape==='kettle'?cream:C);
 ring(r,.012,dark,0,h,0,Math.PI/2);
 if(p.shape==='mug'){ring(.12,.025,dark,.22,.2,0);label(new T.PlaneGeometry(.17,.13),0,.18,.182);}
 if(p.shape==='pot'||p.shape==='kettle'){ball(0,h,0,r,.045,r,cream);ball(0,h+.07,0,.045,.035,.045,dark);}
 if(p.shape==='pot')for(let x of[-.32,.32])ring(.08,.025,dark,x,.2,0,0,Math.PI/2);
 if(p.shape==='kettle'){add(new T.TorusGeometry(.23,.025,6,24,Math.PI),dark,0,.43,0);add(new T.CylinderGeometry(.065,.1,.3,16,1,true),cream,.27,.31,0,0,0,-.9);}break;}
case 'pan':{cyl(.28,.06,dark);box(.12,.07,.42,brown,0,.08,.42);break;}
case 'cutlery':{cyl(.19,.3,C);for(let i=-1;i<=1;i++){box(.025,.58,.025,steel,i*.09,.45);ball(i*.09,.74,0,.05,.07,.02,steel);}break;}
case 'stove':{box(.6,.13,.42,C);ring(.13,.025,dark,0,.16,0,Math.PI/2);for(let x of[-.16,.16])box(.035,.06,.35,dark,x,.18,0);for(let z of[-.16,.16])box(.35,.06,.035,dark,0,.18,z);cyl(.04,.06,steel,.23,.13,.14);break;}
default:ball(0,.25,0,.23,.25,.2,C);
}

const panel={milk:[.32,.22,.188,.42],carton:[.32,.23,.188,.4],sack:[.37,.27,.222,.34],flour:[.35,.26,.222,.34],noodlecup:[.36,.23,.279,.29],sardine:[.39,.13,.193,.13],spam:[.40,.15,.193,.12],packet:[.36,.22,.2,.3],cracker:[.36,.2,.2,.3],dumpling:[.38,.24,.2,.3],petfood:[.38,.27,.2,.3],pasta:[.21,.2,.122,.38],pills:[.24,.19,.185,.22],alcohol:[.25,.19,.185,.22],seed:[.24,.19,.185,.22],pump:[.29,.21,.156,.3],detergent:[.29,.22,.156,.3],tube:[.14,.22,.12,.34],tin:[.35,.22,.248,.31],book:[.28,.24,.132,.45],oil:[.28,.2,.265,.3]};
if(panel[p.shape]){const[w,h,z,y]=panel[p.shape];label(new T.PlaneGeometry(w,h),0,y,z);}
const solid=parts.filter(g=>!g.userData.glass),transparent=parts.filter(g=>g.userData.glass);parts=[...solid,...transparent];
let geometry=mergeGeometries(parts,false);const opaqueCount=solid.reduce((n,g)=>n+g.attributes.position.count,0),glassCount=transparent.reduce((n,g)=>n+g.attributes.position.count,0);geometry.addGroup(0,opaqueCount,0);if(glassCount)geometry.addGroup(opaqueCount,glassCount,1);parts.forEach(g=>g.dispose());geometry.computeBoundingBox();const size=new T.Vector3();geometry.boundingBox.getSize(size);const bounds=geometry.boundingBox.clone(),dim=itemSize(p),sx=dim.w/size.x,sy=dim.h/size.y,sz=dim.d/size.z;geometry.scale(sx,sy,sz);geometry.translate(-(bounds.min.x+bounds.max.x)/2*sx,-bounds.min.y*sy,-(bounds.min.z+bounds.max.z)/2*sz);cache.set(p.id,geometry);return geometry;}
export function itemMesh(p){const m=new T.Mesh(itemGeometry(p),itemMaterial);m.castShadow=true;m.receiveShadow=true;return m;}
export const itemMaterial=[material,glassMaterial];
