// Small, independent bootstrap runs before the engine download starts.
(function(){
 var loading=document.getElementById('loading'),status=document.getElementById('loadstatus'),started=Date.now(),done=false,progress=0,slow;
 function stage(text){if(!done&&status&&!loading.classList.contains('boot-failed'))status.textContent=text;}
 function fail(error){if(done)return;clearTimeout(slow);stage('加载中断，请重试或使用省电模式。存档不会被清除。');loading.classList.add('boot-failed');var detail=document.getElementById('loaddetail');if(detail){detail.hidden=false;detail.textContent=String(error&&error.message||error||'资源未能加载').slice(0,180);} }
 window.__stockpileBoot={stage:stage,asset:function(){progress++;stage('正在准备仓库 '+Math.min(3,progress)+'/3');},fail:fail,ready:function(){done=true;clearTimeout(slow);loading.style.display='none';}};
 window.addEventListener('error',function(e){if(!done)fail(e.error||e.message||'脚本未能启动');});
 window.addEventListener('unhandledrejection',function(e){if(!done)fail(e.reason);});
 slow=setTimeout(function(){if(!done){loading.classList.add('boot-slow');stage('连接较慢，可以继续等待，或重试加载。');}},18000);
 stage('正在下载游戏');
 var game=document.createElement('script');game.src='assets/game.js?v=0.10.0';game.async=true;game.onerror=function(){fail('游戏文件下载失败，请检查连接后重试。');};game.onload=function(){if(!done)stage('正在整理仓库');};document.body.appendChild(game);
 document.getElementById('retryload').onclick=function(e){e.preventDefault();location.reload();};
 var low=document.getElementById('lowload'),url=new URL(location.href);url.searchParams.set('quality','low');url.searchParams.set('v','0.10.0');low.href=url.href;
})();
