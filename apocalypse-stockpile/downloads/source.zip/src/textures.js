import * as T from 'three';
// Local images load independently of JavaScript parsing; one transient failure
// retries once, and an unresponsive image cannot hold the loading screen forever.
export function localTexture(url){
 const texture=new T.Texture(),loader=new T.ImageLoader();let settled=false,attempt=0,timer;
 const ready=new Promise((resolve,reject)=>{
  function fail(){if(settled)return;settled=true;clearTimeout(timer);reject(new Error('图片加载失败：'+url.split('/').pop().split('?')[0]+'。请检查连接后重试。'));}
  function load(){loader.load(url+(attempt?'&retry=1':''),image=>{if(settled)return;settled=true;clearTimeout(timer);texture.image=image;texture.needsUpdate=true;window.__stockpileBoot?.asset();resolve();},undefined,()=>{if(settled)return;if(attempt++===0)setTimeout(load,300);else fail();});}
  timer=setTimeout(fail,25000);load();
 });return{texture,ready};
}
