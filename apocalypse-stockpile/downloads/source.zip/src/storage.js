import {upgrade} from './core.js';
import {zlibSync,unzlibSync,strToU8,strFromU8} from 'fflate';
function timed(p){return new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Storage bridge timeout')),3000);Promise.resolve(p).then(v=>{clearTimeout(timer);resolve(v);},e=>{clearTimeout(timer);reject(e);});});}
const KEY='apocalypse-warehouse-v5';let native=null,queue=Promise.resolve();
export async function prepare(){const x=window.xhs,api=x&&x.miniTool;let launch=x&&x.launchOptions;if(api&&typeof api.getLaunchOptions==='function'&&!launch)launch=await timed(api.getLaunchOptions());const v=Number(launch&&launch.miniToolEnv&&launch.miniToolEnv.buildVersion)||0;if(Math.floor(v/1000)>=9460&&api&&typeof api.getStorage==='function'&&typeof api.setStorage==='function')native=api;}
function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
function encode(s){const raw=JSON.stringify(s),a=zlibSync(strToU8(raw),{level:6});let binary='';for(let i=0;i<a.length;i++)binary+=String.fromCharCode(a[i]);return JSON.stringify({format:'warehouse5-zlib',hash:hash(raw),data:btoa(binary)});}
function decode(raw){const parsed=typeof raw==='string'?JSON.parse(raw):raw;if(parsed?.format!=='warehouse5-zlib')return parsed;const a=Uint8Array.from(atob(parsed.data),c=>c.charCodeAt(0)),text=strFromU8(unzlibSync(a));if(hash(text)!==parsed.hash)throw Error('Save checksum failed');return JSON.parse(text);}
async function get(key){return native?(await timed(native.getStorage({key}))).data:localStorage.getItem(key);}
export async function read(){const current=await get(KEY);if(current!=null&&current!=='')return decode(current);for(const key of['apocalypse-warehouse-v4','apocalypse-warehouse-v3']){const raw=await get(key);if(raw!=null&&raw!=='')return upgrade(decode(raw));}return null;}
export function write(s){const data=encode(s),job=queue.catch(()=>{}).then(async()=>{if(native)await timed(native.setStorage({key:KEY,data}));else localStorage.setItem(KEY,data);});queue=job;return job;}
