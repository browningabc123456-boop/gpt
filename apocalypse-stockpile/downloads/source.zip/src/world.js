import * as T from 'three';
import {mergeGeometries} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
import {FURNITURE,slotPosition,WORLD,placements,ownerAt,pileHeight} from './core.js';
import {itemSize} from './sizes.js';
import {BY_ID} from './catalog.js';
import {createLibrary} from './library.js';
export function createWorld(container){
 const low=new URLSearchParams(location.search).get('quality')==='low',mobile=matchMedia('(max-width:700px)').matches;
 const renderer=new T.WebGLRenderer({antialias:!low,alpha:false,powerPreference:'high-performance'});
 const maxRatio=low?1:Math.min(devicePixelRatio,mobile?1.25:1.5);renderer.setPixelRatio(maxRatio);renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
 renderer.shadowMap.enabled=!low;renderer.shadowMap.autoUpdate=false;renderer.shadowMap.type=T.PCFSoftShadowMap;container.appendChild(renderer.domElement);
 const scene=new T.Scene(),camera=new T.PerspectiveCamera(43,1,.035,500);scene.background=new T.Color('#99aaa3');scene.fog=new T.Fog('#99aaa3',90,220);
 const lib=createLibrary(renderer),env=new RoomEnvironment(),pmrem=new T.PMREMGenerator(renderer);scene.environment=pmrem.fromScene(env,.04).texture;env.dispose();pmrem.dispose();
 const hemi=new T.HemisphereLight('#e2e3d4','#72563c',.85),sun=new T.DirectionalLight('#ffe3b2',2),fill=new T.DirectionalLight('#a2c8d8',.65);sun.position.set(-10,23,18);fill.position.set(5,13,-20);scene.add(hemi,sun,sun.target,fill);
 sun.castShadow=!low;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-16,right:16,top:15,bottom:-15,near:.1,far:65});sun.shadow.bias=-.00015;sun.shadow.normalBias=.008;
 let invalidated=true,current=null,selected=null,shadowAt=0,nearMode=false,stockNearMode=false,motion=false,editing=false,night=null,slowFrames=0,drawMetrics={};
 const groups=new Map(),instanceGroups=new Map(),signatures=new Map(),hits=[],bounds=new Map(),animations=[];
 function surfaceGeometry(g,{tile=0,color='#ffffff',roughness=.7,metalness=0,emission=0}={}){const n=g.getAttribute('position').count,c=new T.Color(color),s=new Float32Array(n*4);for(let i=0;i<n;i++)s.set([c.r,c.g,c.b,tile+Math.round(roughness*15)*256+Math.round(metalness*15)*4096+Math.round(emission/3*7)*65536],i*4);g.setAttribute('surface',new T.BufferAttribute(s,4));return g;}
 const roomPieces=new Map();
 function box(w,h,d,x,y,z,surface={},bucket='static'){const g=surfaceGeometry(new T.BoxGeometry(w,h,d),surface);g.applyMatrix4(new T.Matrix4().makeTranslation(x,y,z));if(!roomPieces.has(bucket))roomPieces.set(bucket,[]);roomPieces.get(bucket).push(g);}
 box(WORLD.w,.18,WORLD.d,0,-.12,0,{color:'#aaa18b',roughness:.9});
 for(let x=-24;x<26;x+=4)box(.014,.004,44,x,-.025,0,{color:'#979380'});for(let z=-20;z<22;z+=4)box(52,.004,.014,0,-.025,z,{color:'#979380'});
 for(const side of['back','left']){
  const put=(w,h,d,x,y,z,s={})=>side==='back'?box(w,h,d,x,y,z,s,side):box(d,h,w,z,y,x,s,side);
  const length=side==='back'?52:44,edge=side==='back'?-22:-26;
  put(length,11,.18,0,5.4,edge,{color:'#a8a18b'});
  for(let x=-length/2+5;x<length/2-2;x+=8){
   put(6.3,6.7,.04,x,6.1,edge+.12,{tile:5,roughness:.24,emission:.18});
   for(const xx of[x-3.2,x+3.2])put(.13,7.0,.15,xx,6.1,edge+.18,{color:'#315247',metalness:.35});
   for(const y of[2.7,6.1,9.5])put(6.5,.10,.17,x,y,edge+.22,{color:'#315247',metalness:.35});
   for(const xx of[x-1.6,x,x+1.6])put(.055,6.7,.14,xx,6.1,edge+.23,{color:'#45665b',metalness:.3});
   put(6.7,.14,.65,x,2.63,edge+.2,{tile:1,roughness:.58});
  }
  for(let x=-length/2+1;x<length/2;x+=8)put(.24,11,.32,x,5.4,edge+.35,{color:'#315247',metalness:.3});
 }
 for(const x of[-18,0,18])for(const z of[-13,7]){box(10,.10,.17,x,10.3,z,{color:'#315247',metalness:.35});box(.025,1.7,.025,x,9.5,z,{color:'#315247'});box(1.2,.08,1.2,x,8.63,z,{color:'#3b5d49',roughness:.4});box(1,.025,1,x,8.58,z,{color:'#ffe2aa',emission:1.8});}
 const roomGroups=[];for(const [side,geometries]of roomPieces){const merged=mergeGeometries(geometries,false),m=new T.Mesh(merged,lib.material);m.receiveShadow=true;m.userData.side=side;scene.add(m);roomGroups.push(m);geometries.forEach(g=>g.dispose());}
 // Soft static contact patches supplement the one local shadow map.
 const c=document.createElement('canvas');c.width=c.height=64;const ctx=c.getContext('2d'),gradient=ctx.createRadialGradient(32,32,8,32,32,32);gradient.addColorStop(0,'rgba(35,38,26,.38)');gradient.addColorStop(1,'rgba(35,38,26,0)');ctx.fillStyle=gradient;ctx.fillRect(0,0,64,64);const contactMaterial=new T.MeshBasicMaterial({map:new T.CanvasTexture(c),transparent:true,depthWrite:false,toneMapped:false});
 function addFurniture(f){const t=FURNITURE[f.type],root=new T.Group();root.position.set(f.x,0,f.z);root.rotation.y=f.r;root.userData={fid:f.id,type:f.type,far:true};const visual=lib.model(f.type,true);visual.traverse(o=>{if(o.isMesh)o.castShadow=f.id===selected&&o.material!==lib.glass;});root.add(visual);root.userData.visual=visual;const stock=new T.Group();root.add(stock);root.userData.stock=stock;
  const hit=new T.Mesh(new T.BoxGeometry(t.w,t.h,t.d),new T.MeshBasicMaterial({visible:false}));hit.position.y=t.h/2;hit.userData.fid=f.id;root.add(hit);root.userData.hit=hit;
  for(let level=0;level<t.levels;level++){const y=slotPosition(f.type,level*t.cols*t.depth).y,plane=new T.Mesh(new T.PlaneGeometry(t.w-.2,t.d-.2),new T.MeshBasicMaterial({visible:false,side:T.DoubleSide}));plane.rotation.x=-Math.PI/2;plane.position.y=y+.015;plane.userData={fid:f.id,level};root.add(plane);hits.push(plane);}
  const contact=new T.Mesh(new T.PlaneGeometry(t.w+1.5,t.d+1.6),contactMaterial);contact.rotation.x=-Math.PI/2;contact.position.y=-.02;root.add(contact);scene.add(root);groups.set(f.id,root);return root;
 }
 function releaseInstances(id){for(const m of instanceGroups.get(id)||[]){m.parent.remove(m);m.dispose();}instanceGroups.delete(id);}
 function removeFurniture(id){releaseInstances(id);const g=groups.get(id);g?.traverse(o=>{if(o===g.userData.hit||hits.includes(o)){o.geometry.dispose();o.material.dispose();}if(o.material===contactMaterial)o.geometry.dispose();});if(g)scene.remove(g);groups.delete(id);bounds.delete(id);signatures.delete(id);for(let i=hits.length-1;i>=0;i--)if(hits[i].userData.fid===id)hits.splice(i,1);}
 const dummy=new T.Object3D();
 function updateStock(f,force=false){const root=groups.get(f.id),far=!(f.id===selected&&stockNearMode),signature=(far?'f':'n')+f.slots.join('|')+JSON.stringify(f.piles);if(!force&&signatures.get(f.id)===signature)return;signatures.set(f.id,signature);
  const entries=placements(f),byId=new Map();for(const e of entries){if(!byId.has(e.id))byId.set(e.id,[]);byId.get(e.id).push(e);}
  const old=instanceGroups.get(f.id)||[],next=[];for(const[id,list]of byId){for(const part of lib.get(id,far)){
   let m=old.find(m=>m.userData.id===id&&m.geometry===part.geometry&&m.instanceMatrix.count>=list.length);if(m)old.splice(old.indexOf(m),1);else m=new T.InstancedMesh(part.geometry,part.material,2**Math.ceil(Math.log2(Math.max(1,list.length))));m.count=list.length;m.castShadow=f.id===selected&&part.kind==='solid';m.receiveShadow=true;m.userData={fid:f.id,id,indices:list.map(e=>e.index),layers:list.map(e=>e.layer)};
   list.forEach((e,i)=>{dummy.position.set(e.x,e.y,e.z);dummy.rotation.set(0,id==='apple'?(e.index%7)*.12:0,0);dummy.scale.setScalar(1);dummy.updateMatrix();m.setMatrixAt(i,dummy.matrix);});m.instanceMatrix.needsUpdate=true;m.computeBoundingSphere();root.userData.stock.add(m);next.push(m);
  }}for(const m of old){m.parent.remove(m);m.dispose();}instanceGroups.set(f.id,next);
  bounds.set(f.id,entries.map(e=>{const d=itemSize(BY_ID[e.id]);return{index:e.index,layer:e.layer,box:new T.Box3(new T.Vector3(e.x-d.w/2,e.y,e.z-d.d/2),new T.Vector3(e.x+d.w/2,e.y+d.h,e.z+d.d/2))};}));
 }
 let selectedBox=null;
 function select(id,state){const changed=selected!==id;selected=id;if(changed){nearMode=false;stockNearMode=false;for(const f of state.furniture){const g=groups.get(f.id);if(!g)continue;if(!g.userData.far){g.remove(g.userData.visual);g.userData.visual=lib.model(f.type,true);g.userData.far=true;g.add(g.userData.visual);}updateStock(f);}for(const[id,g]of groups){g.userData.visual.traverse(o=>{if(o.isMesh)o.castShadow=id===selected&&o.material!==lib.glass;});for(const m of instanceGroups.get(id)||[])m.castShadow=id===selected&&m.material!==lib.glass;}}
  if(selectedBox){scene.remove(selectedBox);selectedBox.geometry.dispose();selectedBox.material.dispose();selectedBox=null;}const f=state.furniture.find(f=>f.id===id);if(f){const t=FURNITURE[f.type],g=new T.BoxGeometry(t.w+.15,.025,t.d+.15);selectedBox=new T.LineSegments(new T.EdgesGeometry(g),new T.LineBasicMaterial({color:'#c1ad72',transparent:true,opacity:.65}));g.dispose();selectedBox.position.set(f.x,.015,f.z);selectedBox.rotation.y=f.r;scene.add(selectedBox);sun.target.position.set(f.x,1,f.z);sun.position.set(f.x-10,23,f.z+18);}invalidate();
 }
 function sync(state,id){current=state;animations.length=0;for(const[id]of groups)if(!state.furniture.some(f=>f.id===id))removeFurniture(id);if(id!==selected)select(id,state);for(const f of state.furniture){const root=groups.get(f.id)||addFurniture(f);root.position.set(f.x,0,f.z);root.rotation.y=f.r;updateStock(f);}select(id,state);invalidate();}
 const ray=new T.Raycaster(),pointer=new T.Vector2();function rayAt(e){const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);}
 function planeAt(e,height=0){rayAt(e);return ray.ray.intersectPlane(new T.Plane(new T.Vector3(0,1,0),-height),new T.Vector3());}
 function floorAt(e){return planeAt(e,0);}
 function furnitureAt(e){rayAt(e);scene.updateMatrixWorld(true);return ray.intersectObjects(Array.from(groups.values()).filter(g=>g.visible).map(g=>g.userData.hit),false)[0]?.object.userData.fid||null;}
 function slotAt(e,state,fid){const root=groups.get(fid);if(!root)return null;rayAt(e);root.updateWorldMatrix(true,true);const planes=ray.intersectObjects(hits.filter(h=>h.userData.fid===fid),false),inverse=root.matrixWorld.clone().invert(),localRay=ray.ray.clone().applyMatrix4(inverse);let item=null,dist=Infinity;for(const b of bounds.get(fid)||[]){const p=localRay.intersectBox(b.box,new T.Vector3());if(!p)continue;const d=p.applyMatrix4(root.matrixWorld).distanceTo(ray.ray.origin);if(d<dist){dist=d;item=b;}}if(item&&(!planes.length||dist<planes[0].distance+.04))return{fid,index:item.index};if(!planes.length)return null;const h=planes[0],f=state.furniture.find(f=>f.id===fid),t=FURNITURE[f.type],p=root.worldToLocal(h.point.clone()),col=Math.max(0,Math.min(t.cols-1,Math.round(p.x/((t.w-.7)/t.cols)+(t.cols-1)/2))),depth=Math.max(0,Math.min(t.depth-1,Math.round(p.z/((t.d-.5)/t.depth)+(t.depth-1)/2)));return{fid,index:h.object.userData.level*t.cols*t.depth+depth*t.cols+col};}
 const hover=new T.Mesh(new T.BoxGeometry(1,.025,1),new T.MeshBasicMaterial({color:'#c2bc80',transparent:true,opacity:.45}));scene.add(hover);hover.visible=false;
 function highlight(hit,state){if(!hit&&!hover.visible)return;hover.visible=!!hit;invalidated=true;if(!hit)return;const f=state.furniture.find(f=>f.id===hit.fid),owner=ownerAt(f,hit.index),id=f.slots[owner],p=slotPosition(f.type,owner>=0?owner:hit.index,id);if(FURNITURE[f.type].stack&&owner>=0)p.y+=pileHeight(f,owner);const d=id?itemSize(BY_ID[id]):{w:.28,d:.28};hover.scale.set(d.w,1,d.d);groups.get(f.id).updateMatrixWorld(true);hover.position.copy(new T.Vector3(p.x,p.y+.025,p.z).applyMatrix4(groups.get(f.id).matrixWorld));hover.rotation.y=f.r;}
 function updateTransform(f){const g=groups.get(f.id);if(g){g.position.set(f.x,0,f.z);g.rotation.y=f.r;}if(selectedBox&&f.id===selected){selectedBox.position.set(f.x,.015,f.z);selectedBox.rotation.y=f.r;}invalidate();}
 // Product thumbnails are produced ahead of time; scrolling/search never reads GPU
 // pixels or synchronously renders 120 extra scenes on the user's main thread.
 const thumbnail=p=>'assets/thumbs/'+p.id+'.webp',furnitureThumbnail=type=>'assets/thumbs/'+type+'.webp';
 function pop(hit){invalidated=true;for(const m of instanceGroups.get(hit.fid)||[]){const index=m.userData.indices.lastIndexOf(hit.index);if(index<0)continue;const base=new T.Matrix4();m.getMatrixAt(index,base);animations.push({mesh:m,index,base,start:performance.now()});}}
 function invalidate(){invalidated=true;shadowAt=performance.now()+160;}
 function cutaway(){if(!current)return;const f=current.furniture.find(f=>f.id===selected),t=f&&FURNITURE[f.type],center=f?new T.Vector3(f.x,t.h*.45,f.z):new T.Vector3(),active=!!f&&!editing&&camera.position.distanceTo(center)<Math.max(28,t.w*3.2)&&camera.getWorldDirection(new T.Vector3()).dot(center.clone().sub(camera.position).normalize())>.6;const points=[];if(active){const root=groups.get(f.id);root.updateWorldMatrix(true,true);for(const [x,y]of[[0,t.h*.45],[-t.w*.4,.25],[t.w*.4,.25],[-t.w*.4,t.h*.8],[t.w*.4,t.h*.8]])points.push(new T.Vector3(x,y,t.d*.3).applyMatrix4(root.matrixWorld));}for(const o of current.furniture){const g=groups.get(o.id);let visible=true;if(active&&o.id!==selected){const d=FURNITURE[o.type];g.updateWorldMatrix(true,true);const inv=g.matrixWorld.clone().invert(),origin=camera.position.clone().applyMatrix4(inv),box=new T.Box3(new T.Vector3(-d.w/2,0,-d.d/2),new T.Vector3(d.w/2,d.h,d.d/2));for(const p of points){const end=p.clone().applyMatrix4(inv),dir=end.clone().sub(origin).normalize(),at=new T.Ray(origin,dir).intersectBox(box,new T.Vector3());if(at&&at.distanceTo(origin)<end.distanceTo(origin)-.25){visible=false;break;}}}if(g.visible!==visible){g.visible=visible;invalidated=true;}}}
 let lastCamera=new T.Vector3(Infinity,Infinity,Infinity),lastQuaternion=new T.Quaternion(),lastMotion=0,lastLOD=0;
 function tick(now){const moved=lastCamera.distanceToSquared(camera.position)>1e-6||lastQuaternion.angleTo(camera.quaternion)>1e-5;if(moved){lastMotion=now;lastCamera.copy(camera.position);lastQuaternion.copy(camera.quaternion);}motion=now-lastMotion<130;if(motion&&stockNearMode){stockNearMode=false;const f=current?.furniture.find(f=>f.id===selected);if(f)updateStock(f);invalidated=true;}if(moved||invalidated)cutaway();
  for(const g of roomGroups)g.visible=g.userData.side==='back'?camera.position.z>-21.6:g.userData.side==='left'?camera.position.x>-25.6:true;
  if(current&&now-lastLOD>250&&!motion){lastLOD=now;const f=current.furniture.find(f=>f.id===selected),distance=f?camera.position.distanceTo(new T.Vector3(f.x,FURNITURE[f.type].h*.4,f.z)):Infinity,near=!low&&distance<14,stockNear=!low&&distance<4.5;if(near!==nearMode||stockNear!==stockNearMode){nearMode=near;stockNearMode=stockNear;for(const f of current.furniture){const root=groups.get(f.id),far=!(f.id===selected&&nearMode);root.remove(root.userData.visual);root.userData.visual=lib.model(f.type,far);root.userData.far=far;root.userData.visual.traverse(o=>{if(o.isMesh)o.castShadow=f.id===selected&&o.material!==lib.glass;});root.add(root.userData.visual);updateStock(f);}invalidate();}}
  if(shadowAt&&now>shadowAt&&!motion&&!animations.length){renderer.shadowMap.needsUpdate=true;invalidated=true;shadowAt=0;}
  if(animations.length)invalidated=true;for(let i=animations.length-1;i>=0;i--){const a=animations[i],t=Math.min(1,(now-a.start)/210),m=a.base.clone();m.elements[13]+=.07*Math.sin(t*Math.PI)*(1-t);a.mesh.setMatrixAt(a.index,m);a.mesh.instanceMatrix.needsUpdate=true;if(t===1)animations.splice(i,1);}
 }
 function lighting(value){if(value===night)return;night=value;sun.intensity=night?1.1:2.0;hemi.intensity=night?.50:.85;fill.intensity=night?.55:.7;lib.material.envMapIntensity=night?.5:.7;scene.background.set(night?'#36515a':'#9cafa5');scene.fog.color.copy(scene.background);invalidate();}
 function resize(){const w=Math.max(1,container.clientWidth),h=Math.max(100,container.clientHeight);renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();invalidate();}resize();window.addEventListener('resize',resize);
 function render(){const start=performance.now();renderer.render(scene,camera);const elapsed=performance.now()-start;drawMetrics={calls:renderer.info.render.calls,triangles:renderer.info.render.triangles,geometries:renderer.info.memory.geometries,textures:renderer.info.memory.textures,cpuRenderMs:elapsed,pixelRatio:renderer.getPixelRatio(),nearMode,stockNearMode};if(motion&&elapsed>28)slowFrames++;else slowFrames=Math.max(0,slowFrames-1);if(slowFrames>8&&renderer.getPixelRatio()>1){renderer.setPixelRatio(Math.max(1,renderer.getPixelRatio()-.25));resize();slowFrames=0;}}
 return{THREE:T,scene,camera,renderer,lib,ready:lib.ready,sync,select,floorAt,furnitureAt,slotAt,highlight,planeAt,thumbnail,furnitureThumbnail,lighting,groups,instanceGroups,updateTransform,pop,tick,render,get metrics(){return drawMetrics;},setEditing(value){if(editing!==value){editing=value;invalidate();}},invalidate,renderPending(){const p=invalidated||animations.length>0;invalidated=false;return p;}};
}
