import * as T from 'three';
export function roomFloor(){
 const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');g.fillStyle='#bdb09a';g.fillRect(0,0,256,256);let seed=894;
 for(let i=0;i<4200;i++){seed=(seed*1664525+1013904223)>>>0;const x=seed%256;seed=(seed*1664525+1013904223)>>>0;const y=seed%256;g.fillStyle=i%2?'#75695410':'#eae0ca12';g.fillRect(x,y,2,1);}
 g.strokeStyle='#776f5c30';g.lineWidth=1;g.strokeRect(.5,.5,255,255);const map=new T.CanvasTexture(c);map.colorSpace=T.SRGBColorSpace;map.wrapS=map.wrapT=T.RepeatWrapping;map.repeat.set(13,11);
 return new T.MeshStandardMaterial({map,color:'#eee4d3',roughness:.91,metalness:.02});
}
