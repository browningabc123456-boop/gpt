import * as T from 'three';
import {ITEMS,CATEGORIES} from './catalog.js';

// One shared label/material atlas keeps the full warehouse instanced and offline.
export const ATLAS=2048;
export const SURFACES={paper:[32,.83,0],metal:[96,.27,.82],fabric:[160,.96,0],ceramic:[224,.28,.05],plastic:[288,.36,0],glass:[352,.12,0],rubber:[416,.88,0]};
export function artUV(geometry,surface='paper',item){
  const uv=geometry.getAttribute('uv');if(!uv)return;
  const index=item?ITEMS.findIndex(p=>p.id===item.id):-1;
  for(let i=0;i<uv.count;i++){
    if(index>=0){const x=(index%8)*256,y=Math.floor(index/8)*128;uv.setXY(i,(x+3+uv.getX(i)*250)/ATLAS,1-(y+3+(1-uv.getY(i))*122)/ATLAS);}
    else uv.setXY(i,(SURFACES[surface]||SURFACES.paper)[0]/ATLAS,1-2016/ATLAS);
  }
}
function canvas(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return[c,c.getContext('2d')];}
function texture(c,repeat){const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;if(repeat){t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(...repeat);}return t;}
let seed=1771;function random(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;}
function leaf(c,x,y,s=1){c.save();c.translate(x,y);c.scale(s,s);c.fillStyle='#60794b';c.beginPath();c.ellipse(-7,-6,10,4,-.5,0,Math.PI*2);c.ellipse(7,-12,11,4,.5,0,Math.PI*2);c.fill();c.strokeStyle='#60794b';c.lineWidth=2;c.beginPath();c.moveTo(0,4);c.lineTo(0,-18);c.stroke();c.restore();}
function illustration(c,p){
  c.save();c.translate(193,80);const food=p.cat==='罐头酱料'||p.cat==='生鲜冷藏';
  if(['water','bigwater'].includes(p.id)){c.fillStyle='#92ada4';c.beginPath();c.moveTo(-70,33);c.lineTo(-30,-18);c.lineTo(-5,4);c.lineTo(20,-32);c.lineTo(63,33);c.closePath();c.fill();c.strokeStyle='#c4d4ca';c.lineWidth=5;c.beginPath();c.moveTo(12,3);c.bezierCurveTo(-28,8,45,24,-45,34);c.stroke();}
  else if(p.cat==='医疗防护'){c.fillStyle='#477064';c.fillRect(-16,-28,12,42);c.fillRect(-31,-13,42,12);}
  else if(['fish','sardine','frozenfish'].includes(p.id)){c.fillStyle='#456777';c.beginPath();c.ellipse(-5,-4,27,12,0,0,Math.PI*2);c.fill();c.beginPath();c.moveTo(-25,-4);c.lineTo(-44,-18);c.lineTo(-44,10);c.closePath();c.fill();c.fillStyle='#f8f5ec';c.beginPath();c.arc(13,-6,2,0,7);c.fill();}
  else if(['milk','oatmilk'].includes(p.id)){c.fillStyle=p.id==='milk'?'#5d7668':'#bb965b';c.beginPath();c.ellipse(-4,-5,29,19,-.1,0,7);c.fill();c.fillStyle='#f3ecda';for(const [x,y]of[[-12,-8],[8,2],[3,-13]]){c.beginPath();c.ellipse(x,y,7,5,.3,0,7);c.fill();}leaf(c,-4,-24,.7);}
  else if(p.id==='petfood'){c.fillStyle='#576b45';c.beginPath();c.ellipse(-8,1,15,12,0,0,7);c.fill();for(const[x,y]of[[-26,-15],[-12,-22],[4,-19],[15,-9]]){c.beginPath();c.ellipse(x,y,6,8,-.3,0,7);c.fill();}}
  else if(['coffee','coffeejar','cocoa'].includes(p.id)){c.fillStyle='#71503c';for(const[x,y]of[[-17,-15],[9,-6],[-12,12]]){c.save();c.translate(x,y);c.rotate(.6);c.beginPath();c.ellipse(0,0,10,16,0,0,7);c.fill();c.strokeStyle='#b69471';c.lineWidth=2;c.beginPath();c.moveTo(0,-12);c.bezierCurveTo(-8,-3,8,3,0,12);c.stroke();c.restore();}}
  else if(p.cat==='粮油主食'){c.strokeStyle='#a98748';c.lineWidth=2;for(let n=-1;n<2;n++){c.save();c.translate(n*17,10);c.rotate(n*.2);c.beginPath();c.moveTo(0,18);c.lineTo(0,-34);c.stroke();c.fillStyle='#c5a765';for(let i=0;i<5;i++)for(const sign of[-1,1]){c.beginPath();c.ellipse(sign*5,-25+i*9,6,3,sign*.65,0,7);c.fill();}c.restore();}}
  else if(food||['juice','peachdrink','soda','coconut'].includes(p.id)){let color=['juice','soda','orange','corn'].includes(p.id)?'#d9a83e':['peach','peachdrink'].includes(p.id)?'#dd9c85':['pickle','beans'].includes(p.id)?'#819953':'#b65c48';c.fillStyle=color;for(const[x,y,r]of[[-15,0,19],[10,-8,22]]){c.beginPath();c.arc(x,y,r,0,7);c.fill();}leaf(c,0,-22,.8);c.fillStyle='#fff6e344';c.beginPath();c.ellipse(-21,-8,4,8,.4,0,7);c.fill();}
  else{leaf(c,-10,-2,1.8);}
  c.restore();
}
export function prepareArtMaterials(materials){
  if(typeof document==='undefined'||materials[0].map)return;
  const [labels,c]=canvas(ATLAS,ATLAS),[surface,r]=canvas(ATLAS,ATLAS);c.fillStyle='#ffffff';c.fillRect(0,0,ATLAS,ATLAS);r.fillStyle='rgb(255,210,0)';r.fillRect(0,0,ATLAS,ATLAS);
  ITEMS.forEach((p,i)=>{const x=(i%8)*256,y=Math.floor(i/8)*128;c.save();c.translate(x,y);c.fillStyle=p.cat==='罐头酱料'?'#e8ddbb':'#f3ecda';c.fillRect(0,0,256,128);c.globalAlpha=.1;for(let n=0;n<110;n++){c.fillStyle=random()>.5?'#86734a':'#fff';c.fillRect(random()*256,random()*128,random()*5+1,1);}c.globalAlpha=1;
    const accent=p.cat==='医疗防护'?'#3b6d62':p.cat==='罐头酱料'?p.color:p.cat==='饮水饮品'?'#31534a':'#687947';
    c.fillStyle=accent;c.fillRect(0,0,256,8);c.fillRect(0,120,256,8);c.font='12px serif';c.fillStyle='#55634e';c.fillText('囤日常',15,29);c.font='bold 26px "PingFang SC","Microsoft YaHei",sans-serif';c.fillStyle='#293e31';const short=p.name.replace('罐头','').replace('饮用','');c.fillText(short,14,65,145);c.font='10px sans-serif';c.fillStyle='#727554';c.fillText(p.cat==='饮水饮品'?'自然滋味 · 每日安心':p.cat==='医疗防护'?'家庭常备 · 安心储备':'妥善收纳 · 好好生活',15,88,145);c.fillStyle=accent;c.fillRect(15,101,50,2);illustration(c,p);c.restore();});
  for(const [x,rough,metal]of Object.values(SURFACES)){c.fillStyle='#fff';c.fillRect(x-30,1984,60,64);r.fillStyle=`rgb(255,${Math.round(rough*255)},${Math.round(metal*255)})`;r.fillRect(x-30,1984,60,64);}
  const colorMap=texture(labels),rm=texture(surface);rm.colorSpace=T.NoColorSpace;
  for(const m of materials){m.map=colorMap;m.roughnessMap=rm;m.metalnessMap=rm;m.roughness=1;m.metalness=1;m.needsUpdate=true;}
}
export function createRoomMaterials(){
  const [oak,g]=canvas(512,128);g.fillStyle='#ae8051';g.fillRect(0,0,512,128);for(let i=0;i<850;i++){g.strokeStyle=`rgba(${random()>.5?'65,38,18':'242,213,166'},${random()*.16})`;g.lineWidth=random()*1.4+.3;g.beginPath();const y=random()*128;g.moveTo(0,y);for(let x=0;x<=512;x+=30)g.lineTo(x,y+Math.sin(x/60+i)*random()*2);g.stroke();}for(let i=0;i<4;i++){g.strokeStyle='#72513822';g.beginPath();g.ellipse(random()*512,random()*128,40,6,0,0,7);g.stroke();}
  const [fabric,f]=canvas(128,128);f.fillStyle='#e7ddc8';f.fillRect(0,0,128,128);for(let i=0;i<128;i+=3){f.strokeStyle='#b7a78d44';f.beginPath();f.moveTo(i,0);f.lineTo(i,128);f.moveTo(0,i);f.lineTo(128,i);f.stroke();}
  const [floor,d]=canvas(512,512);d.fillStyle='#bab19c';d.fillRect(0,0,512,512);for(let n=0;n<18000;n++){d.fillStyle=random()>.5?'#eadcc113':'#665d4a13';d.fillRect(random()*512,random()*512,random()*3+1,random()*2+1);}d.strokeStyle='#786e591f';d.lineWidth=2;d.strokeRect(0,0,512,512);
  const [rain,w]=canvas(512,768);const gradient=w.createLinearGradient(0,0,0,768);gradient.addColorStop(0,'#6e8f9d');gradient.addColorStop(.65,'#9eb2b0');gradient.addColorStop(1,'#c1c4af');w.fillStyle=gradient;w.fillRect(0,0,512,768);for(let n=0;n<32;n++){const x=random()*512,h=80+random()*300;w.fillStyle='#394e541d';w.fillRect(x,768-h,10+random()*25,h);}for(let n=0;n<260;n++){const x=random()*512,y=random()*768;w.strokeStyle='#f3f4dc55';w.lineWidth=.6+random()*1.4;w.beginPath();w.moveTo(x,y);w.lineTo(x-2,y+8+random()*45);w.stroke();}
  const [glow,a]=canvas(128,128);const radial=a.createRadialGradient(64,64,4,64,64,64);radial.addColorStop(0,'rgba(255,207,119,.32)');radial.addColorStop(.4,'rgba(255,207,119,.13)');radial.addColorStop(1,'rgba(255,207,119,0)');a.fillStyle=radial;a.fillRect(0,0,128,128);
  const [contact,b]=canvas(128,128);const soft=b.createRadialGradient(64,64,15,64,64,64);soft.addColorStop(0,'rgba(33,36,24,.28)');soft.addColorStop(1,'rgba(33,36,24,0)');b.fillStyle=soft;b.fillRect(0,0,128,128);
  return{wood:new T.MeshStandardMaterial({color:'#dfbe8f',map:texture(oak,[2,1]),roughness:.68}),floor:new T.MeshStandardMaterial({map:texture(floor,[14,12]),roughness:.77}),fabric:new T.MeshStandardMaterial({map:texture(fabric,[3,3]),roughness:.96}),rain:new T.MeshStandardMaterial({map:texture(rain),emissive:'#9bb8c2',emissiveIntensity:.24,roughness:.23}),glow:new T.MeshBasicMaterial({map:texture(glow),transparent:true,depthWrite:false,toneMapped:false}),contact:new T.MeshBasicMaterial({map:texture(contact),transparent:true,depthWrite:false})};
}
