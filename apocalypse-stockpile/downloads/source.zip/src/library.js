import * as T from 'three';import {localTexture} from './textures.js';
import packed from '../assets/library.json';
import {prepareArtMaterials} from './art.js';
import {unzlibSync} from 'fflate';
import {RoundedBoxGeometry} from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import {FURNITURE,LEGACY_FURNITURE} from './catalog.js';
import {shelfHeight} from './core.js';
// Authored Blender meshes, packed once. No procedural replacement silhouettes.
const bytes=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0)),cache=new Map();
export const modelIds=Array.from(new Set(Object.keys(packed.entries).map(id=>id.replace(/__far$/,''))));
export function createLibrary(renderer){
 const color=localTexture(packed.atlas),normal=localTexture(packed.normal),map=color.texture,normalMap=normal.texture,ready=Promise.all([color.ready,normal.ready]);
 map.colorSpace=T.SRGBColorSpace;map.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());normalMap.anisotropy=map.anisotropy;
 const labelHolder=new T.MeshStandardMaterial();prepareArtMaterials([labelHolder]);const labelsMap=labelHolder.map;labelHolder.roughnessMap.dispose();labelHolder.dispose();
 const material=new T.MeshStandardMaterial({map,normalMap,normalScale:new T.Vector2(.35,.35),roughness:1,metalness:1,envMapIntensity:.6,side:T.DoubleSide,forceSinglePass:true});
 // One draw for all opaque surfaces in a model. Each vertex carries its real
 // material parameters; paint, oak, metal and cloth still respond differently.
 material.onBeforeCompile=shader=>{
  shader.uniforms.labelsMap={value:labelsMap};
  shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nattribute vec4 surface; varying vec4 vSurface; varying vec3 vArtistColor;');
  shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvArtistColor=surface.rgb;float bits=surface.a;vSurface=vec4(mod(bits,256.0),mod(floor(bits/256.0),16.0)/15.0,mod(floor(bits/4096.0),16.0)/15.0,floor(bits/65536.0)/7.0*3.0);');
  shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nvarying vec4 vSurface;varying vec3 vArtistColor;uniform sampler2D labelsMap;\nvec2 atlasUV(vec2 uv){float tile=vSurface.x>=16.0?0.0:floor(vSurface.x+.5);return vec2(mod(tile,4.0),3.0-floor(tile/4.0))*.25+vec2(.00390625)+(fract(uv)*.2421875); }\nvec2 labelUV(vec2 uv){float i=floor(vSurface.x+.5)-16.0;return vec2(mod(i,8.0)*.125,1.0-(floor(i/8.0)+1.0)*.0625)+vec2(.0015)+clamp(uv,0.0,1.0)*vec2(.122,.0595); }');
  shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>','diffuseColor *= vSurface.x>=16.0?texture2D(labelsMap,labelUV(vMapUv)):texture2D(map,atlasUV(vMapUv));diffuseColor.rgb*=vArtistColor;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>','float roughnessFactor = max(.08,vSurface.y);');
  shader.fragmentShader=shader.fragmentShader.replace('#include <metalnessmap_fragment>','float metalnessFactor = vSurface.z;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <emissivemap_fragment>','totalEmissiveRadiance += diffuseColor.rgb*vSurface.w;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>',T.ShaderChunk.normal_fragment_maps.replace(/vNormalMapUv/g,'atlasUV(vNormalMapUv)'));
 };
 const glass=new T.MeshStandardMaterial({color:'#dbe9df',transparent:true,opacity:.16,metalness:.15,roughness:.13,envMapIntensity:1.0,depthWrite:false,side:T.DoubleSide,forceSinglePass:true});
 function geometry(p){const raw=p.compressed?unzlibSync(bytes(p.data)):bytes(p.data),dv=new DataView(raw.buffer,raw.byteOffset,raw.byteLength),pos=new Float32Array(p.vertices*3),normal=new Float32Array(p.vertices*3),uv=new Float32Array(p.vertices*2),surface=new Float32Array(p.vertices*4);
  for(let i=0;i<p.vertices;i++){const at=i*20;for(let k=0;k<3;k++){pos[i*3+k]=p.min[k]+dv.getUint16(at+k*2,true)/65535*p.span[k];normal[i*3+k]=dv.getInt8(at+6+k)/127;surface[i*4+k]=raw[at+13+k]/255;}for(let k=0;k<2;k++)uv[i*2+k]=dv.getUint16(at+9+k*2,true)/65535*32-16;surface[i*4+3]=raw[at+16]+Math.round(raw[at+17]/255*15)*256+Math.round(raw[at+18]/255*15)*4096+Math.round(raw[at+19]/255*7)*65536;}
  const ix=p.compressed?unzlibSync(bytes(p.indices)):bytes(p.indices),aligned=ix.slice().buffer,idx=p.indexBytes===4?new Uint32Array(aligned):new Uint16Array(aligned),g=new T.BufferGeometry();g.setAttribute('position',new T.BufferAttribute(pos,3));g.setAttribute('normal',new T.BufferAttribute(normal,3));g.setAttribute('uv',new T.BufferAttribute(uv,2));g.setAttribute('surface',new T.BufferAttribute(surface,4));g.setIndex(new T.BufferAttribute(idx,1));g.computeBoundingBox();g.computeBoundingSphere();g.userData={triangles:p.triangles,kind:p.kind};return g;
 }
 function get(id,far=false){const request=id+(far?'__far':''),key=packed.entries[request]?request:id+'__far';if(!cache.has(key)){const parts=packed.entries[key];if(!parts)throw Error('模型缺失：'+key);cache.set(key,parts.map(p=>({geometry:geometry(p),material:p.kind==='glass'?glass:material,kind:p.kind})));}return cache.get(key);}
 const furnitureCache=new Map();
 function furnitureParts(type,levels,far){const key=type+'|'+levels+'|'+far;if(furnitureCache.has(key))return furnitureCache.get(key);const t=FURNITURE[type],old=LEGACY_FURNITURE[type],parts=[];
  for(const p of get(type,far)){const g=p.geometry.clone(),pos=g.getAttribute('position'),normal=g.getAttribute('normal'),uv=g.getAttribute('uv'),surface=g.getAttribute('surface'),idx=g.index,indices=[];
   for(let i=0;i<idx.count;i+=3){const a=idx.getX(i),b=idx.getX(i+1),c=idx.getX(i+2),lo=Math.min(pos.getY(a),pos.getY(b),pos.getY(c)),hi=Math.max(pos.getY(a),pos.getY(b),pos.getY(c));let remove=false;if(!t.deep)for(let l=0;l<old.levels;l++){const y=.55+l*(old.h-.9)/old.levels;if(lo>=y-.275&&hi<=y+.045)remove=true;}if(type==='cabinet'&&hi<.60&&Math.min(pos.getZ(a),pos.getZ(b),pos.getZ(c))>old.d*.47)remove=true;if(!remove)indices.push(a,b,c);}
   g.setIndex(indices);for(let i=0;i<pos.count;i++){const x=pos.getX(i)*t.w/old.w,y=pos.getY(i)*t.h/old.h,z=pos.getZ(i)*t.d/old.d;pos.setXYZ(i,x,y,z);if(Math.round(surface.getW(i))%256===1){const nx=Math.abs(normal.getX(i)),ny=Math.abs(normal.getY(i)),nz=Math.abs(normal.getZ(i));if(ny>nx&&ny>nz)uv.setXY(i,x*.55,z*.55);else if(nx>nz)uv.setXY(i,z*.55,y*.55);else uv.setXY(i,x*.55,y*.55);}}g.computeBoundingBox();g.computeBoundingSphere();parts.push({geometry:g,material:p.material});
  }
  if(!t.deep)for(let level=0;level<levels;level++){const y=shelfHeight({type,levels},level),g=new RoundedBoxGeometry(t.w-.12,.06,t.d-.12,2,.009);g.translate(0,y-.035,0);const pos=g.getAttribute('position'),n=g.getAttribute('normal'),uv=g.getAttribute('uv'),surface=new Float32Array(pos.count*4),glassShelf=['fridge','glass'].includes(type);for(let i=0;i<pos.count;i++){const nx=Math.abs(n.getX(i)),ny=Math.abs(n.getY(i)),nz=Math.abs(n.getZ(i)),x=pos.getX(i),yy=pos.getY(i),z=pos.getZ(i);uv.setXY(i,(nx>ny&&nx>nz?z:x)*.55,(ny>nx&&ny>nz?z:yy)*.55);surface.set([1,1,1,1+9*256],i*4);}g.setAttribute('surface',new T.BufferAttribute(surface,4));parts.push({geometry:g,material:glassShelf?glass:material});
   const edge=new RoundedBoxGeometry(t.w-.12,.045,.035,2,.008);edge.translate(0,y-.025,t.d/2-.055);const v=new Float32Array(edge.getAttribute('position').count*4),color=new T.Color(type==='wood'?'#93724e':'#294d3c');for(let i=0;i<v.length/4;i++)v.set([color.r,color.g,color.b,7*256+4*4096],i*4);edge.setAttribute('surface',new T.BufferAttribute(v,4));parts.push({geometry:edge,material});
  }
  furnitureCache.set(key,parts);return parts;
 }
 function model(id,far=false,levels){const group=new T.Group(),parts=FURNITURE[id]?furnitureParts(id,levels||FURNITURE[id].levels,far):get(id,far);for(const p of parts){const mesh=new T.Mesh(p.geometry,p.material);mesh.castShadow=p.material!==glass;mesh.receiveShadow=true;group.add(mesh);}return group;}
 return{get,model,material,glass,ready,map,normalMap,ids:modelIds};
}
