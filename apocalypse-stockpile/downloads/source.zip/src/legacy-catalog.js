// Supply registry. Game meshes come from the authored Blender library; collision dimensions remain in sizes.js.
const groups={
'饮水饮品':[
['water','矿泉水','water','#a5d2d6'],['bigwater','大桶饮用水','jug','#87bac6'],['soda','柠檬汽水','soda','#d2cf73'],['cola','可乐','cola','#8f4d39'],['tea','乌龙茶','tea','#aaba6d'],['juice','橙汁','juice','#e5ad48'],['peachdrink','蜜桃饮','juice','#dda4a0'],['milk','纯牛奶','milk','#c7d6e1'],['oatmilk','燕麦奶','milk','#d5be8c'],['coffee','冷萃咖啡','coffee','#845a41'],['coconut','椰子水','carton','#adc18e'],['energy','运动饮料','sport','#bba5d0']],
'粮油主食':[
['rice','大米布袋','sack','#e6d7b5'],['flour','小麦面粉','flour','#ded2b4'],['oats','燕麦片','oats','#c8a575'],['noodle','方便面杯','noodlecup','#c77f54'],['ramen','袋装泡面','packet','#d8b65d'],['pasta','长条意面','pasta','#c7a45b'],['bread','全麦面包','bread','#be8b55'],['cracker','压缩饼干','cracker','#c2a47b'],['oil','食用油','oil','#dab44c'],['salt','海盐','salt','#d1d6ca'],['sugar','白砂糖','sack','#e9dcca'],['honey','蜂蜜','honey','#d49c3c'],['coffeejar','速溶咖啡','coffeejar','#805641'],['cocoa','可可粉','tin','#987a61'],['lentil','红豆','sack','#b9907e'],['cornmeal','玉米粉','flour','#d3bb70']],
'罐头酱料':[
['fish','金枪鱼罐头','flatcan','#7fa3aa'],['sardine','沙丁鱼罐头','sardine','#849e88'],['beans','茄汁豆罐头','can','#b96e55'],['corn','甜玉米罐头','can','#d4be62'],['spam','午餐肉罐头','spam','#b87e75'],['peach','黄桃罐头','fruitjar','#d7aa4c'],['pickle','酸黄瓜','pickle','#7b9c59'],['jam','草莓果酱','jam','#ae5e66'],['soup','番茄浓汤','can','#b56a53'],['sauce','番茄酱','sauce','#b45140'],['soy','酱油','soy','#6c4c3a'],['butter','花生酱','jam','#b79260']],
'生鲜冷藏':[
['apple','红苹果','apple','#bc6754'],['orange','鲜橙','orange','#e6a14b'],['banana','香蕉串','banana','#e2c962'],['carrot','胡萝卜','carrot','#db8e42'],['cabbage','卷心菜','cabbage','#99b46e'],['potato','土豆','potato','#bb9d71'],['tomato','番茄','tomato','#c9614b'],['egg','鸡蛋托盘','eggs','#e6d7ba'],['cheese','芝士块','cheese','#e4c363'],['meat','鲜肉托盘','meat','#c87f7a'],['frozenfish','冷冻鱼','fish','#96b4b7'],['dumpling','冷冻水饺','dumpling','#dae3d6']],
'医疗防护':[
['med','急救箱','medkit','#ede6d3'],['bandage','绷带卷','bandage','#e6dcc3'],['pills','常备药瓶','pills','#e5e2cf'],['blister','药片板','blister','#aeb9bb'],['mask','防护口罩','mask','#b4d1d3'],['gloves','防护手套','gloves','#b5cbd4'],['alcohol','消毒酒精','alcohol','#b6d1cf'],['thermo','体温计','thermo','#d9e1da'],['goggle','护目镜','goggle','#99bec6'],['respirator','防毒面具','respirator','#818b76']],
'洗护清洁':[
['tissue','抽纸','tissue','#b5c5b1'],['roll','卫生纸卷','roll','#ece4d3'],['soap','香皂','soap','#d1b29f'],['shampoo','洗发水','pump','#b3a3bc'],['wash','洗手液','pump','#a6c5c0'],['tooth','牙膏','tube','#c5d7c7'],['brush','牙刷','brush','#a5c4b7'],['detergent','洗衣液','detergent','#a7b9c6'],['towel','折叠毛巾','towel','#c9b3a0'],['sponge','清洁海绵','sponge','#d3c078'],['trash','垃圾袋卷','trash','#7f9284'],['bucket','水桶','bucket','#9fb8b1']],
'照明能源':[
['flashlight','手电筒','flashlight','#80918a'],['lantern','露营灯','lantern','#b2a882'],['candle','蜡烛','candle','#ead9ac'],['battery','电池组','batteries','#8a9a80'],['powerbank','充电宝','powerbank','#cbcbbb'],['solar','折叠太阳能板','solar','#667d92'],['generator','应急发电机','generator','#ad9968'],['gas','燃气罐','gas','#b47e66'],['matches','火柴盒','matches','#b7976a'],['radio','收音机','radio','#8a9f91'],['walkie','对讲机','walkie','#778a7d'],['cable','充电线卷','cable','#9ba69b']],
'工具装备':[
['hammer','铁锤','hammer','#9aa4a1'],['axe','手斧','axe','#b49b72'],['shovel','折叠铲','shovel','#889d8a'],['wrench','扳手','wrench','#a5b2b1'],['knife','工具刀','knife','#7f9387'],['rope','绳索圈','rope','#baa37c'],['tape','胶带','tape','#c3af89'],['toolbox','工具箱','toolbox','#9da889'],['extinguisher','灭火器','extinguisher','#bd6855'],['lock','挂锁','lock','#bbad82'],['scissors','剪刀','scissors','#8bada0'],['compass','指南针','compass','#b4a779']],
'保暖露营':[
['blanket','毛毯卷','blanket','#bdac92'],['sleepingbag','睡袋','sleepingbag','#8d9f83'],['backpack','登山包','backpack','#95a17e'],['tent','帐篷收纳袋','tent','#b0a07b'],['boots','防水靴','boots','#8b9482'],['coat','保暖外套','coat','#b09d86'],['socks','厚袜子','socks','#c0b394'],['gloveswarm','保暖手套','gloves','#b7a58a'],['hotwater','热水袋','hotwater','#b58b7e'],['mat','防潮垫卷','mat','#a0af96']],
'炊具生活':[
['pot','汤锅','pot','#b4bab3'],['pan','平底锅','pan','#76827b'],['kettle','烧水壶','kettle','#b5bdb3'],['mug','搪瓷杯','mug','#dedbc8'],['bowl','饭碗','bowl','#dbd8bd'],['cutlery','餐具筒','cutlery','#adbaa6'],['stove','便携炉','stove','#a1a99a'],['bento','饭盒','bento','#bdc8b4'],['petfood','宠物粮袋','petfood','#b99c72'],['book','生存手册','book','#99a58c'],['notebook','笔记本','book','#bca88e'],['seed','蔬菜种子罐','seed','#a1af80']]
};
export const CATEGORIES=Object.keys(groups);
export const ITEMS=[];for(const cat of CATEGORIES)for(const [id,name,shape,color] of groups[cat])ITEMS.push({id,name,shape,color,cat,sound:CATEGORIES.indexOf(cat)});
export const BY_ID=ITEMS.reduce((o,p)=>(o[p.id]=p,o),{});
export const FURNITURE={
wood:{name:'长木货架',w:12,d:3.5,h:5.2,cols:16,depth:4,levels:3,color:'#ad8252'},
metal:{name:'工业钢架',w:14,d:4,h:6.1,cols:18,depth:5,levels:4,color:'#31534a'},
cabinet:{name:'分格储物柜',w:10,d:3.4,h:5.2,cols:12,depth:4,levels:3,color:'#af8b5c'},
fridge:{name:'双门冰箱',w:4.5,d:3.5,h:5.8,cols:5,depth:4,levels:4,color:'#e4dfce'},
freezer:{stack:true,name:'卧式冷柜',w:7,d:3.5,h:2.5,cols:9,depth:4,levels:1,color:'#e4dfce'},
partition:{name:'独立长隔板',w:11,d:3.5,h:2.2,cols:14,depth:4,levels:1,color:'#af8b5c'},
pegboard:{name:'工具储物台',w:9,d:3.5,h:4.8,cols:11,depth:4,levels:2,color:'#31534a'},
wardrobe:{name:'双门衣柜',w:7,d:4,h:6.8,cols:8,depth:4,levels:2,color:'#ad8252'},
glass:{name:'透明展示柜',w:8,d:3.8,h:6,cols:10,depth:4,levels:4,color:'#31534a'},
crate:{name:'实木储物箱',stack:true,w:5,d:4,h:2.7,cols:6,depth:5,levels:1,color:'#ad8252'},
chest:{name:'带盖储物箱',stack:true,w:6,d:4,h:3.4,cols:7,depth:5,levels:1,color:'#31534a'},
bin:{name:'透明收纳箱',stack:true,w:4.5,d:3.5,h:2.6,cols:5,depth:4,levels:1,color:'#c5ddd7'},
wire:{name:'金属网格架',w:10,d:3.8,h:5.7,cols:12,depth:4,levels:4,color:'#31534a'},
locker:{name:'铁皮储物柜',w:7,d:3.8,h:6.5,cols:8,depth:4,levels:3,color:'#31534a'},
basket:{name:'藤编收纳筐',stack:true,w:4,d:3.5,h:2.2,cols:5,depth:4,levels:1,color:'#b39462'}
};

// Finer packing grid: small everyday items share a shelf with much larger gear.
for(const t of Object.values(FURNITURE)){t.cols*=2;t.depth*=2;}
