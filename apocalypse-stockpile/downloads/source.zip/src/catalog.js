import {FOODS} from './food-catalog.js';
import {ITEMS as LEGACY_ITEMS,FURNITURE as LEGACY_FURNITURE} from './legacy-catalog.js';
export {LEGACY_FURNITURE};
const oldFood=new Set(['饮水饮品','粮油主食','罐头酱料','生鲜冷藏']);
export const ITEMS=FOODS.concat(LEGACY_ITEMS.filter(p=>!oldFood.has(p.cat)));
export const CATEGORIES=Array.from(new Set(ITEMS.map(p=>p.cat)));
export const BY_ID=ITEMS.reduce((o,p)=>(o[p.id]=p,o),{});
const spec={
 wood:['长木货架',7.2,1.6,4.1,5],metal:['食品钢木长架',8.8,1.7,4.6,6],cabinet:['分格储物柜',5.4,1.4,3.8,5],fridge:['双门冰箱',2.4,1.65,4.1,6],freezer:['卧式冷柜',3.6,1.65,1.8,1,true],partition:['低层储物长台',6,1.6,1.65,1],pegboard:['工具储物台',4.8,1.4,3.6,4],wardrobe:['双门衣柜',3.6,1.4,4.2,4],glass:['透明食品柜',4.8,1.4,4.0,4],crate:['实木储物箱',2.4,1.6,1.2,1,true],chest:['带盖储物箱',2.8,1.6,1.4,1,true],bin:['透明收纳箱',1.5,1.1,.95,1,true],wire:['金属网格架',5.4,1.5,4.1,6],locker:['铁皮储物柜',2.4,1.2,3.9,5],basket:['藤编收纳筐',1.2,1.0,.70,1,true]
};
export const FURNITURE={};
for(const [id,[name,w,d,h,levels,deep=false]]of Object.entries(spec))FURNITURE[id]={name,w,d,h,levels,deep,stack:true,base:deep?.12:.22,margin:.10,cols:Math.max(8,Math.round((w-.2)/.04)),depth:Math.max(8,Math.round((d-.2)/.04)),color:LEGACY_FURNITURE[id].color};
export const FOOD_COUNT=FOODS.length;
