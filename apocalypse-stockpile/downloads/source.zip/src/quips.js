import {BY_ID} from './catalog.js';
export const THRESHOLDS=[5,15,30,60,100,200,500,1000];
const general=[
 '末日还没来，我的补货速度已经领先了。','这一世，我先把购物车变成仓库。','安全感有了形状：一排，再叠一排。','问就是刚需，细问就是提前准备。','别人等快递，我等货架说装不下。','不怕计划有变，先把库存安排明白。','这叫有备无患，才不是舍不得停手。','这一世，我的梦想是随手就能拿到。','囤货人的数学：再加一排，刚刚好。','我只是补一点点，怎么又是一整层。','末日可以突然，补货不能临时。','别人给未来写信，我给未来留饭。'
];
const byCategory={
 '米面主食':['这一世，我不再对着空米缸思考人生。','末日来临，主食怎么能少？先保住我的饭碗。','末日生存第一步：先回答今天吃什么。','饭可以晚点做，米必须提前有。','这一排，是未来的碳水自由。','不管外面什么天气，这里都有开饭底气。','上一世点外卖，这一世直接管粮仓。','别的计划再说，干饭计划先落实。'],
 '肉菜罐头':['开罐即开饭，末日也要有点效率。','这一世，我终于端上了真正的铁饭碗。','罐头排得越整齐，心里越有数。','别问保镖在哪，这排铁罐就是饭保镖。','拉环一开，今天的厨艺直接满分。','这不是罐头墙，这是我的加餐计划。','末日来了也不能天天只啃饼干。','不用等厨房开门，我自己就是备餐站。'],
 '瓶罐调味':['活下来很重要，吃得有味道也很重要。','别人研究末日路线，我先研究蘸料搭配。','这一世，我拒绝让饭菜只有一个味道。','末日可以艰苦，我的拌饭不能寡淡。','酱料一到位，普通食材也能申请出道。','先囤调味料，以防未来只能靠想象下饭。','这排看着是瓶瓶罐罐，其实是吃饭的尊严。','仓库里的隐藏高手，全在调料这一层。'],
 '蔬果生鲜':['末日菜单里，蔬菜也必须有姓名。','排得这么整齐，菜市场老板看了都想进货。','这一世，我连配菜都提前安排好了。','别光顾着囤零食，给清爽口留个位置。','库存要丰富，颜色也要丰富。','囤是认真囤，记得优先吃新鲜的。','这格是生鲜区，先吃顺序已经写进脑子里。','末日来了，我也想有一口脆生生。'],
 '速食冷冻':['这一世，半夜饿了不用翻空冰箱。','冰柜满了，今天不想做饭的底气也满了。','末日菜单可以复杂，做饭过程必须简单。','这叫战略速食储备，不叫懒得下厨。','今晚吃什么？冰柜已经帮我做好选择题。','先冻起来，以防未来的我突然想加餐。','冰柜一开，厨艺门槛当场降低。','别人囤计划，我囤能直接下锅的。'],
 '零食干货':['末日都来了，总得给自己留点小快乐。','这一世，我不再把最后一包留到过期。','战略储备里，零食也算精神物资。','多囤点，以防未来嘴巴突然想上班。','先声明：这一排不是今天一天的量。','我可以暂时不吃，但它必须在那里。','危机可以来，追剧搭子不能缺席。','这是应急储备，嘴馋也属于紧急情况吧。'],
 '饮水饮品':['这一世，我不再半夜发现最后一瓶没了。','末日来临，喝的怎么能少？先把这一排排齐。','水要备够，快乐饮料也想申请一个位置。','这不是饮料墙，是我给未来留的补给站。','别人举杯庆祝，我先把整排摆稳。','多囤一排，以防未来的我只想伸手拿。','先给口渴安排后路，再考虑别的剧情。','囤货人的快乐：瓶盖朝齐，库存到位。'],
 '烘焙早餐':['这一世，我不再空着肚子想早饭吃什么。','末日也有早上，早餐储备当然不能少。','先把明天安排明白，再把后天也安排上。','我的生存计划里，早餐从不被跳过。','多囤点，以防未来的我起床只想开饭。','早餐这一格，看着就像能多睡十分钟。','末日闹钟可以响，早饭不能没有着落。','这一排，是我给清晨留的退路。'],
 '医疗防护':['这一格先备好，需要时就不用翻箱倒柜。','囤的时候讲究整齐，取的时候讲究好找。','这一世，我先把家中常备安排齐。'],
 '洗护清洁':['末日可以乱，我的仓库和头发尽量不乱。','这一世，我给干净也留了一整格。','先摆整齐，未来打扫时少找半天。'],
 '照明能源':['先备好，以防未来摸黑找手电。','别人等一道光，我先把灯备上。','这一世，找东西不用全凭手感。'],
 '工具装备':['工具摆到位，临时找不到的剧情就删掉。','这一世，我先修好自己的后勤系统。','多备一点，以防关键时刻只差这一件。'],
 '衣物寝具':['末日也要睡好，后勤不许掉链子。','这一世，我先给温暖安排一个柜子。','外面风大，这格先替未来兜着。'],
 '炊具容器':['有锅有碗，开饭计划正式成立。','这一世，我不再对着食材问锅在哪。','装备齐了，厨艺可以慢慢练。']
};
const special={
 rice:['这一世，我的饭碗牢牢端在自己手里。','大米多囤点，以防末日的我饭量突然翻倍。'],ramen:['这一世，我不再等室友分我最后一包泡面。','末日来了，泡面也得有得挑。'],noodle:['这一格先备好，未来的加班夜有了安排。'],cola:['末日可以紧张，我的快乐不能没气。','这一世，可乐终于不用按口分了。'],water:['末日来临，水怎么能少？先把基础补给摆稳。'],toiletpaper:['多囤点，以防末日最尴尬的不是没电。','这一世，我不再隔着门喊谁还有纸。'],tissue:['这一世，纸抽到最后一张也有下一盒。'],coffee:['末日可以到来，咖啡因不能断供。'],coffeebeans:['这一世，末日也拦不住我认真开机。'],chocolate:['先留一格甜，以防未来需要哄哄自己。'],dumpling:['末日也要像过节一样，有饺子才像一顿。'],hotpot:['别人准备逃生路线，我先准备火锅底料。'],pot:['这一世，我可以没有大厨，但不能没有锅。']
};
export const QUIP_COUNT=general.length+Object.values(byCategory).reduce((n,a)=>n+a.length,0)+Object.values(special).reduce((n,a)=>n+a.length,0);
export function createQuips(random=Math.random){
 let counts={},added={},pending=null,lastShown=-Infinity,lastText='';const seen=new Set(),used=new Map();
 function rebase(s){counts={};added={};pending=null;for(const f of s.furniture){for(const id of f.slots)if(id)counts[id]=(counts[id]||0)+1;for(const pile of Object.values(f.piles))for(const id of pile)counts[id]=(counts[id]||0)+1;}for(const id of s.migrationUnplaced||[])counts[id]=(counts[id]||0)+1;}
 function change(id,delta=1){if(!BY_ID[id])return;const before=counts[id]||0,previous=added[id]||0;counts[id]=Math.max(0,before+delta);if(delta<=0){if(pending?.id===id&&counts[id]<pending.threshold)pending=null;return;}added[id]=previous+delta;
  for(const threshold of THRESHOLDS){const key=id+':'+threshold;if(counts[id]>=threshold&&!seen.has(key)&&((before<threshold&&counts[id]>=threshold)||(previous<threshold&&added[id]>=threshold))){seen.add(key);pending={id,n:counts[id],threshold};}}
  if(pending?.id===id)pending.n=counts[id];
 }
 function take(now){const item=pending;pending=null;if(!item||counts[item.id]<item.threshold||now-lastShown<15000)return null;const p=BY_ID[item.id],pool=[...(special[p.id]||[]),...(byCategory[p.cat]||[]),...general],previous=used.get(p.id)||new Set();let choices=pool.filter(t=>!previous.has(t)&&t!==lastText);if(!choices.length){previous.clear();choices=pool.filter(t=>t!==lastText);}const text=choices[Math.floor(random()*choices.length)];previous.add(text);used.set(p.id,previous);lastText=text;lastShown=now;return{title:p.name+' × '+(counts[p.id]||item.n),text,id:p.id,count:counts[p.id]||item.n};}
 return{rebase,change,take,get count(){return counts;}};
}
