export const SCENES=[
 {id:'granary',name:'暖木粮仓',hint:'原木地板 · 午后暖光',wall:'#c8b493',frame:'#50674e',trim:'#a57a4b',floor:'#b79265',seam:'#795e42',sky:['#a6c3c0','#f3d9a4'],background:'#aaa58e',light:'#ffe3ac',ground:'#796549',pattern:'wood'},
 {id:'rain',name:'雨夜仓库',hint:'青灰墙面 · 窗外细雨',wall:'#899591',frame:'#34564d',trim:'#998367',floor:'#a79f8c',seam:'#686e60',sky:['#344d61','#8bacae'],background:'#737f79',light:'#ffd29c',ground:'#4d5c54',pattern:'tile'},
 {id:'forest',name:'林间储藏室',hint:'松绿窗景 · 清晨柔光',wall:'#bdc4a6',frame:'#456146',trim:'#8f784d',floor:'#a38c63',seam:'#6e6449',sky:['#91b7a3','#dce3b1'],background:'#8e9e82',light:'#f6e4af',ground:'#596b4b',pattern:'wood'},
 {id:'coast',name:'海边物资站',hint:'沙色墙面 · 海风晴窗',wall:'#d4c5a6',frame:'#597e82',trim:'#b0a285',floor:'#c0b89e',seam:'#99977f',sky:['#83bacc','#dfecd9'],background:'#a6beb8',light:'#fff1d1',ground:'#778b7f',pattern:'tile'}
];
export const SCENE_BY_ID=SCENES.reduce((o,t)=>(o[t.id]=t,o),{});
