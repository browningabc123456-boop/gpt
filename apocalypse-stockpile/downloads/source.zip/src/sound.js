let muted=false,index=0,lastAt=-Infinity,warned=false;const pools={},active=[],warmed=new Set();
const legacy=['glass','paper','metal','soft','plastic','plastic','wood','wood','fabric','ceramic'];
const families=['glass','paper','metal','soft','plastic','wood','fabric','ceramic','lift','complete','furniture'];
function family(kind){return typeof kind==='number'?legacy[kind]||'wood':families.includes(kind)?kind:'wood';}
export function soundFor(p){
 if(!p)return 'wood';const name=p.name||'',shape=p.shape||'';
 if(/玻璃|果酱|蜂蜜|酱油|醋|酒瓶/.test(name)||shape==='jar')return 'glass';
 if(/铁罐|罐头|奶粉|罐装|金属/.test(name)||['can','largecan','tin','sardine'].includes(shape))return 'metal';
 if(/布袋|纸盒|纸包装|牛皮袋|纸袋|袋|米|面粉|麦片/.test(name)||/bag|sack|packet|carton|box/.test(shape))return 'paper';
 if(/水果|蔬菜|鸡蛋|白菜|土豆|番茄|苹果|橙|瓜|柠檬|青菜|面包|吐司|餐包|馒头/.test(name)||/fruit|bread|egg|vegetable/.test(shape))return 'soft';
 if(/瓶|塑料|泵|饮用水|汽水|可乐|牛奶/.test(name)||/bottle|water|cola|soda|milk/.test(shape))return 'plastic';
 return legacy[p.sound]||'wood';
}
function pool(name){if(!pools[name])pools[name]=Array.from({length:3},(_,i)=>{const a=new Audio('assets/place-'+name+'-'+i+'.wav?v=0.10.0');a.preload='auto';a.volume=.48;a.__generation=0;return a;});return pools[name];}
function stopAll(){for(const ps of Object.values(pools))for(const a of ps){a.__generation++;a.pause();try{a.currentTime=0;}catch{}}active.length=0;}
export function setMute(v){muted=v;if(v)stopAll();}
export function unlock(kind){if(muted)return;const name=family(kind);if(warmed.has(name))return;warmed.add(name);for(const a of pool(name)){const generation=++a.__generation;a.volume=0;try{const p=a.play();if(p&&p.then)p.then(()=>{if(a.__generation===generation){a.pause();a.currentTime=0;}},()=>{});}catch{}}}
export function sound(kind,volume=1){
 const now=performance.now();if(muted||document.hidden||now-lastAt<75)return;lastAt=now;
 try{const name=family(kind),a=pool(name)[index++%3];a.__generation++;while(active.length&&active[0].paused)active.shift();if(active.length>=3)active.shift().pause();a.pause();a.currentTime=0;a.volume=Math.min(name==='paper'?.66:.52,(name==='paper'?.60:.48)*volume);active.push(a);const p=a.play();if(p&&p.catch)p.catch(()=>{if(!warned){warned=true;window.dispatchEvent(new Event('soundblocked'));}});}catch{}
}
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopAll();});
