"""Full authored asset library. Reuses the eight approved Blender prototypes.
Blender axes: x width, y depth (negative = front), z up. No old game meshes.
"""
import pathlib,json,math,bpy,random
from math import sin,cos,pi
BASE=pathlib.Path('/workspace/work/shelter')
sample=pathlib.Path('/workspace/work/shelter-sample/source/build_assets.py').read_text()
# Execute the actual approved source assets, including their UVs and micro normals.
exec(sample.split('# A textured warehouse corner')[0])
catalog=json.loads((BASE/'production/catalog.json').read_text())
approved={'water','rice','fish','honey','apple','towel','pot','lantern'}
roots['metal']=roots.pop('rack');roots['metal'].name='metal'

# Economy helpers keep shape-specific details while reducing invisible segments.
old_curve=curve
def curve(name,points,r,mat,closed=False):
 o=old_curve(name,points,r,mat,closed);o.data.bevel_resolution=1;return o
old_box=box
def box(name,loc,dims,mat,r=.015):
 o=old_box(name,loc,dims,mat,r)
 for m in o.modifiers:
  if m.type=='BEVEL':m.segments=2
 return o
def ell(name,loc,dims,mat,segments=24,rings=12):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,radius=1,location=loc)
 o=finish(bpy.context.object,name,mat);o.scale=dims;return o
def tag(name,loc,w,h,tile=0):
 o=box(name,loc,(w,.001,h),labels,0);atlas_uv(o,tile);return o
def bottle(p,col,jar=False,pump=False):
 h=.65 if not jar else .43;r=.14 if jar else .105
 profile=[(0,.012),(r*.82,.012),(r,.035),(r,.69*h),(r*.88,.79*h),(r*.49,.88*h),(r*.47,h)] if not jar else [(0,.01),(r*.9,.01),(r,.04),(r,h*.88),(r*.88,h),(0,h)]
 body=lathe('Moulded bottle with shoulder',profile,col,40)
 cap=green if p['cat']!='医疗防护' else cream
 cyl('Threaded cap',(0,0,h+.018),r*(.55 if not jar else 1),.06,cap,32)
 ring('Base moulding',r*.93,.035,.003,col)
 wrap_label('Curved illustrated sleeve',r+.001,h*.2,h*.42,3 if jar else 0,pi*1.25)
 for i in range(24):
  a=i*pi/12;rr=r*(.55 if not jar else 1);curve('Cap grip',[(rr*sin(a),rr*cos(a),h-.005),(rr*sin(a),rr*cos(a),h+.043)],.0017,cap)
 if pump:
  cyl('Pump collar',(0,0,h+.078),.043,.07,steel,24)
  box('Pump spout',(.045,0,h+.13),(.16,.045,.03),green,.009)
 return body
def sack(p,col,flat=False):
 # Each bag has an inflated cloth/foil surface, a gusset and crimped ends.
 N=32;R=20;verts=[];faces=[]
 for j in range(R+1):
  t=j/R;w=.27+.06*sin(pi*t);d=.04+.14*sin(pi*t)**.5
  for i in range(N+1):
   a=i*2*pi/N;wr=.006*sin(a*10+t*26)
   verts.append((math.copysign(abs(cos(a))**.55,cos(a))*(w+wr),math.copysign(abs(sin(a))**.65,sin(a))*(d+wr),t*.8+.004*cos(a*7)))
 for j in range(R):
  for i in range(N):a=j*(N+1)+i;faces.append((a,a+1,a+N+2,a+N+1))
 faces += [tuple(range(N,-1,-1)),tuple(R*(N+1)+i for i in range(N+1))]
 m=bpy.data.meshes.new('Inflated gusset bag');m.from_pydata(verts,[],faces);m.update();o=obj('Sealed bag with folds',m,col)
 uv=m.uv_layers.new(name='UVMap')
 for poly in m.polygons:
  for li in poly.loop_indices:v=m.loops[li].vertex_index;uv.data[li].uv=(v%(N+1)/N*2,v//(N+1)/R*2)
 for z in[.01,.79]:
  curve('Crimped sewn edge',[(-.27+i*.54/24,.004*sin(i*1.6),z)for i in range(25)],.009,col)
  for i in range(15):box('Heat seal ridges',(-.25+i*.035,-.045,z),(.008,.015,.018),cream,.001)
 tag('Printed panel',(0,-.18,.42),.30,.27,1)
def can(p,col,oval=False):
 r=.15;h=.35
 lathe('Drawn steel body',[(0,.005),(r,.005),(r,.025),(r*.97,.03),(r*.97,h-.03),(r,h-.02),(r,h),(0,h)],col,40)
 for z in[.012,h-.008]:ring('Rolled can seam',r,z,.007,steel)
 cyl('Recessed lid',(0,0,h-.002),r*.91,.012,steel,40)
 for rr in[.09,.12]:ring('Pressed lid ring',rr,h+.005,.0015,steel)
 curve('Pull tab',[(.025+.02*cos(i*pi/12),.03*sin(i*pi/12),h+.012)for i in range(24)],.004,steel,True)
 wrap_label('Paper can wrapper',r*.98,.05,h-.10,2,pi*1.97)
def carton(p,col):
 box('Folded carton body',(0,0,.24),(.30,.23,.48),col,.008)
 verts=[(-.15,-.115,.48),(.15,-.115,.48),(-.15,.115,.48),(.15,.115,.48),(-.15,0,.59),(.15,0,.59)]
 m=bpy.data.meshes.new('Gable top');m.from_pydata(verts,[],[(0,1,5,4),(2,4,5,3),(0,4,2),(1,3,5)]);obj('Folded gable',m,col,False)
 box('Sealed top seam',(0,0,.60),(.30,.025,.03),cream,.003)
 cyl('Pouring cap',(.06,-.06,.54),.035,.025,cream,24,(.7,0,0))
 tag('Front carton illustration',(0,-.116,.27),.25,.27,0 if p['id'] not in ['milk','oatmilk'] else 1)
def fabric_roll(p,col):
 for i in range(3):
  cyl('Rolled textile cross section',(0,0,.23),.22-i*.013,.7,col,40,(0,pi/2,0))
 curve('Spiral fabric edge',[(.356,(.025+.19*t/90)*sin(t*.19),.23+(.025+.19*t/90)*cos(t*.19))for t in range(91)],.005,thread)
 for x in[-.23,.23]:
  o=ring('Woven compression strap',.23,.0,.018,green);o.rotation_euler[1]=pi/2;o.location=(x,0,.23)
  box('Strap buckle',(x,-.239,.24),(.08,.02,.055),steel,.004)
def make(p):
 asset(p['id']);shape=p['shape'];col=material(p['id']+' finish',p['color'],.58,.03)
 if shape in ['jug','oil','detergent']:
  bottle(p,col);curve('Moulded handle',[(.12,-.01,.48),(.25,-.01,.48),(.26,-.01,.26),(.14,-.01,.24)],.025,col)
  if shape=='jug':
   for z in[.12,.19,.34,.41]:ring('Water jug rib',.11,z,.006,col)
 elif shape in ['soda','cola','tea','juice','coffee','sport','sauce','soy','pills','alcohol','pump','honey','coffeejar','fruitjar','pickle','jam','seed']:
  bottle(p,col,shape in ['coffeejar','fruitjar','pickle','jam','seed'],shape=='pump')
 elif shape in ['milk','carton']:carton(p,col)
 elif shape in ['sack','flour','packet','pasta','cracker','dumpling','petfood']:sack(p,cotton if shape in ['sack','flour','petfood'] else col)
 elif shape in ['can','flatcan','tin','oats','sardine','spam','salt']:
  can(p,col)
  if shape in ['sardine','spam']:
   for o in [o for o in bpy.data.objects if o.parent==current]:o.scale.y=.62
 elif shape in ['orange','tomato','potato']:
  for i in range(3 if shape=='potato' else 1):
   o=ell('Natural fruit skin',((i-1)*.08 if shape=='potato' else 0,0,.11),(.12,.1,.105),col)
   for v in o.data.vertices:v.co*=1+.025*sin(v.co.x*47+v.co.z*31)
  if shape=='tomato':
   for i in range(5):a=i*2*pi/5;curve('Tomato calyx',[(0,0,.21),(.06*sin(a),.06*cos(a),.204)],.008,leafmat)
  if shape=='orange':
   cyl('Citrus stem',(0,0,.215),.008,.012,brown,16)
 elif shape=='banana':
  for j in range(4):
   pts=[(-.14+.32*i/20,-.045+j*.037,.04+.17*sin(i*pi/25)+j*.012)for i in range(21)];curve('Curved banana',pts,.027,col);ell('Dark banana tip',pts[0],(.016,.018,.016),brown,12,6)
  curve('Banana joined stem',[(.17,-.04,.17),(.19,.05,.2)],.02,brown)
 elif shape=='carrot':
  lathe('Tapered root',[(0,0),(.012,.02),(.05,.25),(.04,.31),(0,.32)],col,32)
  for j in range(5):curve('Carrot greens',[(0,0,.32),(.04*sin(j*2),.04*cos(j*2),.42)],.007,leafmat)
  for z in[.08,.14,.21]:ring('Root growth line',.015+z*.11,z,.0015,brown)
 elif shape=='cabbage':
  ell('Cabbage heart',(0,0,.17),(.17,.16,.17),col)
  for j in range(8):
   a=j*pi/4;leaf=ell('Layered curved cabbage leaf',(.07*sin(a),.07*cos(a),.17),(.115,.035,.16),leafmat if j%2 else col);leaf.rotation_euler=(.15*sin(a),.15*cos(a),-a)
   curve('Leaf rib',[(.15*sin(a),.15*cos(a),.07),(.17*sin(a),.17*cos(a),.19),(.1*sin(a),.1*cos(a),.30)],.003,cream)
 elif shape=='eggs':
  box('Moulded pulp egg tray',(0,0,.018),(.52,.32,.035),cotton,.022)
  for x in[-.18,0,.18]:
   for y in[-.08,.08]:ell('Individual egg',(x,y,.075),(.06,.045,.074),cream,24,12)
 elif shape in ['meat','fish','cheese']:
  if shape=='fish':
   ell('Fish body',(0,0,.065),(.24,.06,.06),steel);ell('Fish eye',(.17,-.051,.08),(.012,.004,.012),darksteel,16,8)
   curve('Tail fork',[(-.20,0,.06),(-.31,0,.11),(-.27,0,.06),(-.31,0,.01),(-.20,0,.06)],.017,col,True)
   for x in[-.12,-.07,-.02,.03,.08]:curve('Fish skin details',[(x,-.056,.04),(x+.025,-.059,.07)],.0015,greenlight)
  else:
   box('Lipped food tray',(0,0,.02),(.48,.32,.04),cream,.025)
   for i in range(3 if shape=='meat' else 1):
    box('Marbled portion' if shape=='meat' else 'Cheese block',((i-1)*.12 if shape=='meat' else 0,0,.06),(.14 if shape=='meat' else .3,.24,.065),col,.023)
    if shape=='meat':curve('Natural fat line',[((i-1)*.12-.03,-.1,.096),((i-1)*.12+.02,0,.099),((i-1)*.12-.01,.1,.096)],.004,cream)
 elif shape=='bread':
  ell('Baked loaf',(0,0,.12),(.25,.13,.12),col,32,16)
  for x in[-.13,-.04,.05,.14]:curve('Scored bread crust',[(x,-.1,.18),(x+.025,0,.24),(x+.02,.10,.18)],.006,cotton)
 elif shape=='noodlecup':
  lathe('Paper cup',[(0,.01),(.11,.01),(.16,.28),(.16,.30),(0,.30)],col,40);ring('Peel lid rim',.16,.30,.005,steel);wrap_label('Cup sleeve',.146,.08,.15,1,pi*1.6)
 elif shape in ['medkit','toolbox','bento','powerbank','radio','generator','stove','solar','book','matches','blister','tissue']:
  W,H,D={'medkit':(.58,.38,.30),'toolbox':(.85,.48,.45),'bento':(.42,.14,.28),'powerbank':(.18,.035,.30),'radio':(.48,.32,.2),'generator':(1.2,.9,.8),'stove':(.6,.18,.45),'solar':(1.3,.04,1.0),'book':(.34,.5,.06),'matches':(.1,.03,.07),'blister':(.15,.02,.24),'tissue':(.4,.18,.25)}[shape]
  body=box('Manufactured housing',(0,0,H/2),(W,H,D),col,min(.035,H*.18))
  if shape in ['toolbox','medkit']:
   box('Lid seam',(0,0,H*.69),(W+.005,.012,D+.005),darksteel,.004)
   curve('Recessed carry handle',[(-W*.18,0,H),( -W*.18,0,H+.10),(W*.18,0,H+.10),(W*.18,0,H)],.018,green)
   for x in[-W*.3,W*.3]:box('Lock clasp',(x,-D/2-.014,H*.67),(.05,.02,.08),steel,.004)
   if shape=='medkit':box('Medical emblem vertical',(0,-D/2-.002,H*.39),(.045,.008,.16),green,.002);box('Medical emblem horizontal',(0,-D/2-.008,H*.39),(.16,.008,.045),green,.002)
  elif shape=='radio':
   cyl('Speaker',( -.10,-D/2-.004,H*.45),.09,.012,darksteel,40,(pi/2,0,0))
   for x in[-.15,-.12,-.09,-.06]:box('Speaker grille',(x,-D/2-.014,.14),(.008,.01,.13),greenlight,.001)
   box('Tuning dial',(.12,-D/2-.012,.22),(.13,.018,.045),cream,.002)
   for x in[.08,.17]:cyl('Volume knob',(x,-D/2-.02,.08),.026,.028,steel,24,(pi/2,0,0))
   curve('Telescopic antenna',[(.17,0,H),(.34,0,H+.35)],.005,steel)
  elif shape=='generator':
   for x in[-W/2,W/2]:curve('Tubular crash frame',[(x,-D*.56,.04),(x,-D*.56,H+.07),(x,D*.56,H+.07),(x,D*.56,.04)],.035,darksteel)
   for x in[-.42,.42]:cyl('Rubber wheel',(x,D/2,.10),.12,.07,darksteel,32,(0,pi/2,0))
   for i in range(9):box('Engine ventilation',( -.33+i*.07,-D/2-.01,H*.4),(.027,.02,.3),darksteel,.003)
   cyl('Fuel cap',(.25,0,H+.03),.07,.04,steel,32)
  elif shape in ['stove','solar']:
   if shape=='stove':
    for rr in[.055,.12]:ring('Burner ring',rr,H+.015,.012,darksteel)
    for j in range(4):a=j*pi/2;curve('Pot support',[(.09*sin(a),.09*cos(a),H+.02),(.19*sin(a),.19*cos(a),H+.05)],.014,steel)
    cyl('Gas dial',(.21,-D/2,.09),.03,.035,green,24,(pi/2,0,0))
   else:
    for i in range(8):
     for j in range(5):box('Individual photovoltaic cell',(-.55+i*.155,-.4+j*.195,H+.002),(.14,.18,.002),darksteel,.003)
    for x in[-.63,.63]:box('Panel edge',(x,0,H/2),(.025,H+.01,D),steel,.003)
  elif shape=='tissue':
   box('Tissue slot',(0,0,H+.001),(.23,.025,.004),darksteel,.01)
   o=box('Soft pulled tissue',(.025,0,H+.045),(.15,.007,.12),cream,.01);o.rotation_euler[1]=-.25
  elif shape=='blister':
   for x in[-.04,.04]:
    for y in[-.08,0,.08]:ell('Tablet blister bubble',(x,y,H),(.025,.033,.015),cream,16,8)
  elif shape=='book':
   box('Ivory page block',(.004,0,H/2),(W-.035,H-.035,D-.018),cotton,.001)
   for y in[-D/2,D/2]:box('Book cover',(0,y,H/2),(W,.008,H),green,.001)
   tag('Book cover drawing',(0,-D/2-.005,H*.53),W*.7,H*.6,1)
  elif shape=='powerbank':
   for i in range(4):ell('Battery status light',(-.05+i*.03,-D/2-.001,H*.5),(.004,.002,.003),light,8,4)
  else:box('Lid lip',(0,0,H*.9),(W+.008,.012,D+.008),cream,.003)
 elif shape in ['bandage','roll','tape','trash','rope','cable']:
  major=.14 if shape in ['rope','cable'] else .07;minor=.025
  count=6 if shape in ['rope','cable'] else 1
  for j in range(count):
   o=ring('Coiled material',major,.035+j*.016,minor,cotton if shape in ['rope','bandage','roll'] else col)
  if shape in ['roll','bandage','tape']:
   lathe('Hollow rolled layers',[(.028,.005),(.09,.005),(.09,.17),(.028,.17),(.028,.005)],col,48)
   lathe('Cardboard inner tube',[(.025,.003),(.029,.003),(.029,.172),(.025,.172),(.025,.003)],brown,32)
 elif shape in ['blanket','sleepingbag','tent','mat']:fabric_roll(p,fabric if shape=='blanket' else col)
 elif shape in ['coat','gloves','socks','backpack','hotwater','boots','mask','respirator','goggle']:
  if shape=='boots':
   for x in[-.13,.13]:
    ell('Boot toe',(x,-.11,.07),(.10,.19,.065),col)
    lathe('Boot shaft',[(.09,.05),(.095,.43),(.10,.45),(.077,.45),(.073,.09)],col,32).location.x=x
    box('Treaded sole',(x,-.06,.023),(.21,.33,.045),darksteel,.02)
  elif shape in ['gloves','socks']:
   for x in[-.1,.1]:
    box('Fabric palm',(x,0,.14),(.15,.035,.18),col,.035)
    for j in range(4):ell('Soft fingers',(x-.055+j*.038,0,.27+j%2*.015),(.018,.02,.075),col,12,8)
    ell('Thumb',(x+.09,0,.17),(.035,.025,.075),col,12,8)
    box('Ribbed cuff',(x,0,.035),(.16,.045,.07),fabric,.012)
  elif shape=='coat':
   box('Padded jacket torso',(0,0,.45),(.56,.12,.65),col,.06)
   for sign in[-1,1]:
    o=box('Articulated sleeve',(sign*.36,0,.46),(.18,.13,.62),col,.06);o.rotation_euler[1]=sign*.22
    for z in[.2,.33,.46,.59,.72]:curve('Quilted seam',[(sign*.18,-.066,z),(sign*.04,-.07,z)],.003,thread)
   curve('Jacket zipper',[(0,-.07,.15),(0,-.07,.77)],.006,steel)
   ring('Padded collar',.12,.79,.025,col)
  elif shape=='backpack':
   box('Soft pack body',(0,0,.46),(.56,.3,.8),col,.12);box('Front zipped pocket',(0,-.17,.28),(.4,.12,.3),fabric,.055)
   for x in[-.17,.17]:curve('Padded shoulder strap',[(x,.14,.75),(x,.29,.5),(x,.18,.11)],.034,col)
   for z in[.28,.65]:curve('Compression straps',[(-.29,-.16,z),(.29,-.16,z)],.012,green)
   curve('Carry loop',[(-.09,0,.85),(-.09,0,.93),(.09,0,.93),(.09,0,.85)],.015,green)
  elif shape in ['mask','goggle']:
   box('Contoured protective face',(0,0,.08),(.3,.07,.15),col,.05)
   for z in[.05,.08,.11]:curve('Pleated mask line',[(-.12,-.037,z),(0,-.045,z+.005),(.12,-.037,z)],.002,cream)
   for sign in[-1,1]:curve('Elastic ear loop',[(sign*.14,0,.14),(sign*.22,0,.16),(sign*.23,0,.02),(sign*.14,0,.02)],.004,cream)
  elif shape=='respirator':
   ell('Moulded respirator',(0,0,.15),(.17,.12,.15),col)
   for x in[-.14,.14]:cyl('Filter cartridge',(x,-.09,.12),.075,.08,darksteel,32,(pi/2,0,0))
   for x in[-.07,.07]:ell('Eye lens',(x,-.095,.24),(.055,.02,.045),jarGlass,24,12)
  else:
   ell('Rubber hot water pouch',(0,0,.22),(.16,.055,.21),col);cyl('Stopper',(0,0,.44),.035,.04,cream,24)
   for i in range(7):curve('Raised rubber ribs',[(-.11+i*.035,-.054,.1),(-.11+i*.035,-.057,.33)],.003,col)
 elif shape in ['pan','kettle','mug','bowl','cutlery','bucket']:
  if shape in ['pan','bowl','mug','bucket','cutlery']:
   r=.20 if shape in ['pan','bucket'] else .12;h=.08 if shape=='pan' else .28
   lathe('Hollow vessel with inside',[(0,.008),(r*.8,.008),(r,h),(r-.014,h),(r*.8-.014,.025),(0,.025)],cream if shape in ['mug','bowl'] else col,48)
   ring('Rolled rim',r,h,.006,green)
   if shape=='pan':curve('Long pan handle',[(0,.19,.06),(0,.48,.07)],.032,darksteel)
   if shape=='mug':curve('Cup handle',[(.12,0,.22),(.22,0,.24),(.23,0,.07),(.12,0,.06)],.018,green)
   if shape=='bucket':curve('Wire bail',[(.20*cos(i*pi/24),0,.26+.20*sin(i*pi/24))for i in range(25)],.007,steel)
   if shape=='cutlery':
    for i in range(5):curve('Cutlery handle',[(-.07+i*.035,0,.12),(-.08+i*.04,0,.46+i%2*.02)],.008,steel);ell('Spoon bowl',(-.08+i*.04,0,.49+i%2*.02),(.019,.01,.035),steel,16,8)
  else:
   lathe('Kettle rounded body',[(0,.01),(.19,.01),(.23,.10),(.20,.31),(.13,.35),(0,.35)],steel,48)
   curve('Pour spout',[(.19,0,.14),(.28,0,.22),(.33,0,.32)],.035,steel)
   curve('Arched kettle handle',[(.20*cos(i*pi/32),0,.31+.21*sin(i*pi/32))for i in range(33)],.025,green)
   cyl('Kettle lid',(0,0,.36),.13,.025,cream,32);ell('Lid knob',(0,0,.39),(.025,.025,.025),wood)
 elif shape in ['flashlight','candle','gas','extinguisher','walkie','batteries','tube','brush','thermo']:
  if shape=='flashlight':
   lathe('Flashlight barrel',[(0,.01),(.06,.01),(.06,.30),(.11,.36),(.115,.44),(0,.44)],col,40)
   cyl('Reflector glass',(0,0,.443),.098,.008,cream,32)
   for z in[.08,.11,.14,.17,.20,.23]:ring('Knurled grip',.062,z,.003,darksteel)
  elif shape in ['gas','extinguisher']:
   lathe('Pressure cylinder',[(0,.008),(.12,.008),(.17,.045),(.17,.55),(.13,.61),(.04,.64)],col,40)
   cyl('Valve stem',(0,0,.68),.025,.09,brass,24)
   if shape=='extinguisher':
    curve('Squeezable metal handle',[(-.07,0,.74),(.13,0,.74),(.14,0,.69)],.013,darksteel)
    curve('Flexible hose',[(.04,0,.68),(.23,0,.66),(.24,0,.34),(.20,0,.12)],.016,darksteel)
   else:ring('Protective valve guard',.08,.73,.014,col)
   wrap_label('Safety cylinder label',.172,.18,.22,1,pi*.9)
  elif shape=='candle':
   cyl('Wax cylinder',(0,0,.14),.065,.28,cream,40);curve('Cotton wick',[(0,0,.28),(0,0,.295)],.002,darksteel)
  elif shape=='batteries':
   for x in[-.035,.035]:cyl('Cell',(x,0,.065),.03,.13,col,24);cyl('Positive terminal',(x,0,.135),.014,.01,steel,16);ring('Metal cell cap',.03,.13,.002,steel,x,0)
  elif shape=='walkie':
   box('Radio body',(0,0,.16),(.13,.08,.3),col,.015);curve('Antenna',[(-.035,0,.30),(-.035,0,.46)],.012,darksteel)
   box('LCD',(0,-.043,.23),(.09,.004,.05),greenlight,.002)
   for z in[.07,.09,.11,.13]:box('Speaker slit',(0,-.043,z),(.075,.005,.008),darksteel,.001)
  elif shape=='tube':
   lathe('Squeezable tube',[(0,.01),(.035,.01),(.04,.05),(.04,.23),(.025,.30),(0,.30)],col,32);cyl('Tube cap',(0,0,.02),.037,.04,cream,24);box('Crimped tube end',(0,0,.31),(.07,.015,.02),steel,.001)
  elif shape=='brush':
   curve('Toothbrush handle',[(0,0,.02),(.012,0,.2),(0,0,.31)],.012,col);box('Bristle head',(0,0,.32),(.04,.018,.07),cream,.005)
   for z in[.3,.315,.33,.345]:curve('Bristle rows',[(-.014,-.018,z),(.014,-.018,z)],.004,cream)
  else:
   box('Thermometer stem',(0,0,.14),(.035,.025,.28),cream,.012);box('Digital display',(0,-.014,.19),(.025,.003,.04),greenlight,.002);cyl('Steel sensor',(0,0,.01),.009,.04,steel,16)
 elif shape in ['hammer','axe','shovel','wrench','knife','scissors','lock','compass']:
  if shape in ['hammer','axe','shovel']:
   curve('Contoured wooden handle',[(0,0,.02),(.01,0,.35),(0,0,.63)],.025,wood)
   if shape=='hammer':box('Forged hammer head',(0,0,.61),(.30,.10,.10),steel,.015)
   elif shape=='axe':
    verts=[(-.04,-.035,.59),(.25,-.03,.52),(.27,-.03,.76),(-.04,-.035,.67),(-.04,.035,.59),(.25,.03,.52),(.27,.03,.76),(-.04,.035,.67)]
    m=bpy.data.meshes.new('Wedge axe head');m.from_pydata(verts,[],[(0,1,2,3),(4,7,6,5),(0,4,5,1),(1,5,6,2),(2,6,7,3),(3,7,4,0)]);bevel(obj('Forged wedge blade',m,steel,False),.008,2)
   else:
    ell('Concave shovel blade',(0,0,.72),(.15,.025,.20),steel);curve('D grip',[(-.08,0,.02),(-.08,0,-.08),(.08,0,-.08),(.08,0,.02)],.018,darksteel)
  elif shape=='wrench':
   box('Forged wrench shank',(0,0,.22),(.05,.018,.37),steel,.012)
   for z in[.025,.42]:
    curve('Open wrench jaw',[(-.055,0,z+.04),(-.06,0,z-.02),(0,0,z-.055),(.06,0,z-.02),(.055,0,z+.04)],.018,steel)
  elif shape=='knife':
   box('Textured tool grip',(0,0,.09),(.06,.03,.18),green,.012);box('Steel blade',(0,0,.29),(.05,.008,.22),steel,.004)
  elif shape=='scissors':
   for sign in[-1,1]:
    curve('Scissor handle loop',[(sign*.04+.03*cos(i*2*pi/24),0,.05+.05*sin(i*2*pi/24))for i in range(24)],.009,col,True)
    curve('Scissor blade',[(sign*.04,0,.09),(-sign*.055,0,.30)],.011,steel)
   cyl('Pivot screw',(0,0,.15),.013,.014,brass,16,(pi/2,0,0))
  elif shape=='lock':
   box('Brass lock body',(0,0,.05),(.12,.04,.10),brass,.009);curve('Steel shackle',[(-.04,0,.10),(-.04,0,.17),(0,0,.19),(.04,0,.17),(.04,0,.10)],.008,steel)
  else:
   cyl('Compass case',(0,0,.018),.06,.035,brass,40);cyl('Compass dial',(0,0,.037),.052,.004,cream,32)
   for i in range(16):a=i*pi/8;curve('Dial ticks',[(.045*sin(a),.045*cos(a),.04),(.05*sin(a),.05*cos(a),.04)],.001,green)
   curve('Compass needle',[(0,-.04,.043),(0,.04,.043)],.004,green)
 elif shape=='soap':
  box('Rounded milled soap bar',(0,0,.03),(.17,.11,.06),col,.022)
  curve('Pressed leaf mark',[(-.025,-.001,.061),(0,0,.064),(.025,.001,.061)],.0018,cream)
 elif shape=='sponge':
  box('Cellulose sponge',(0,0,.04),(.2,.13,.07),col,.015);box('Scouring pad',(0,0,.079),(.2,.13,.012),fabric,.006)
 else:raise RuntimeError('Missing authored shape: '+shape)

for p in catalog['items']:
 if p['id'] not in approved:make(p)
 print('MADE',p['id'],flush=True)

# Storage furniture: actual panels, recessed interiors, usable shelf heights.
def panel(name,x,y,z,w,d,h,mat,r=.025):return box(name,(x,y,z),(w,d,h),mat,r)
def shelf(t,z,mat=wood):
 W,D=t['w'],t['d'];panel('Usable shelf',0,0,z-.065,W-.20,D-.17,.13,mat,.025)
 panel('Shelf front edge',0,-D/2+.06,z-.055,W-.14,.045,.10,steel if mat==jarGlass else mat,.012)
def door(t,sign,mat,transparent=False,fridge=False):
 W,D,H=t['w'],t['d'],t['h'];doorW=W/2;objects_before=set(bpy.data.objects)
 panel('Rounded outer door skin',-sign*doorW/2,0,H/2,doorW-.06,.17,H-.14,mat,.10 if fridge else .035)
 if transparent:
  for x in[-sign*.04,-sign*(doorW-.04)]:panel('Door stile',x,-.04,H/2,.08,.15,H-.13,green,.018)
  for z in[.08,H-.08]:panel('Door rail',-sign*doorW/2,-.04,z,doorW,.15,.09,green,.018)
 if fridge:
  # Interior liner, perimeter gasket, molded door bins and clear front walls.
  panel('Moulded door liner',-sign*doorW/2,.11,H/2,doorW-.23,.07,H-.32,cream,.08)
  for x in[-sign*.13,-sign*(doorW-.13)]:panel('Magnetic rubber door seal',x,.155,H/2,.035,.035,H-.28,darksteel,.01)
  for z in[.15,H-.15]:panel('Magnetic rubber door seal',-sign*doorW/2,.155,z,doorW-.26,.035,.035,darksteel,.01)
  for z in[.65,1.8,3.2]:
   panel('Door bottle bin base',-sign*doorW/2,.30,z,doorW-.38,.42,.065,cream,.025)
   panel('Clear door bin lip',-sign*doorW/2,.51,z+.14,doorW-.38,.035,.28,jarGlass,.018)
   for x in[-sign*.19,-sign*(doorW-.19)]:panel('Door bin end',x,.32,z+.14,.04,.40,.28,jarGlass,.015)
 # Curved handle with two metal mounting bosses.
 x=-sign*(doorW-.22)
 curve('Arched pull handle',[(x,-.10,H*.42),(x,-.24,H*.45),(x,-.24,H*.65),(x,-.10,H*.68)],.045,steel if fridge else brass)
 # Keep open doors fully clear of usable interior, hinge at the real side edge.
 from mathutils import Matrix
 angle=sign*1.20;rot=Matrix.Rotation(angle,4,'Z');origin=Vector((sign*W/2,-D/2,0))
 for o in set(bpy.data.objects)-objects_before:o.matrix_world=Matrix.Translation(origin)@rot@o.matrix_world
 for z in[.35,H-.35]:cyl('Visible hinge pin',(sign*W/2,-D/2,z),.065,.32,steel,24)

for typ,t in catalog['furniture'].items():
 if typ=='metal':continue
 asset(typ);W,D,H=t['w'],t['d'],t['h'];stack=t.get('stack',False)
 if typ in ['wood','partition','wire','pegboard']:
  for x in[-W/2+.12,W/2-.12]:
   for y in[-D/2+.12,D/2-.12]:
    panel('Solid oak upright' if typ in ['wood','partition'] else 'Steel upright',x,y,H/2,.23,.23,H,wood if typ in ['wood','partition'] else green,.025)
    panel('Foot plate',x,y,.07,.35,.35,.14,darksteel,.02)
  if typ=='pegboard':
   panel('Tool backboard',0,D/2-.03,H*.72,W,.13,H*.54,wood,.025)
   for x in range(int(W*3)):
    for z in range(6):cyl('Pegboard inset hole',(-W/2+.2+x*.32,D/2-.11,H*.48+z*.32),.025,.015,darksteel,8,(pi/2,0,0))
   for x in[-W/3,0,W/3]:curve('Bent steel tool hook',[(x,D/2-.14,H*.75),(x,D/2-.32,H*.75),(x,D/2-.32,H*.83)],.018,steel)
  for lev in range(t['levels']):
   z=.55+lev*(H-.9)/t['levels'];shelf(t,z)
   if typ=='wire':
    for i in range(int(W*3)):curve('Load bearing wire', [(-W/2+.2+i*.32,-D/2,z+.025),(-W/2+.2+i*.32,D/2,z+.025)],.012,steel)
   for x in[-W/2+.13,W/2-.13]:
    for y in[-D/2+.1,D/2-.1]:cyl('Bracket hex bolt',(x,y-.12,z-.07),.05,.035,steel,6,(pi/2,0,0))
  curve('Diagonal brace',[(-W/2+.1,D/2,.25),(W/2-.1,D/2,H-.2)],.028,green)
  if typ=='wood':panel('Crown shelf',0,0,H-.06,W,D,.14,wood,.03)
 elif typ in ['fridge','cabinet','wardrobe','glass','locker']:
  isfridge=typ=='fridge';m=cream if isfridge else jarGlass if typ=='glass' else green if typ=='locker' else wood
  # Interior is a cavity, not a solid cube. No obstacle at placement surfaces.
  panel('Recessed back',0,D/2,H/2,W,.18,H,m,.06 if isfridge else .025)
  for x in[-W/2,W/2]:panel('Thick cabinet side',x,0,H/2,.16,D,H,m,.05)
  for z in[.13,H-.07]:panel('Top or plinth',0,0,z,W,D,.16,m,.06)
  for x in[-W/2+.3,W/2-.3]:
   for y in[-D/2+.28,D/2-.28]:cyl('Adjustable foot',(x,y,.1),.13,.2,darksteel,24)
  for lev in range(t['levels']):shelf(t,.55+lev*(H-.9)/t['levels'],jarGlass if isfridge or typ=='glass' else wood if typ!='locker' else green)
  if isfridge:
   for x in[-W/4,W/4]:
    panel('Vegetable drawer bottom',x,0,.30,W/2-.25,D-.30,.07,cream,.04)
    panel('Clear vegetable drawer front',x,-D/2+.18,.42,W/2-.25,.045,.30,jarGlass,.035)
    curve('Drawer finger grip',[(x-.25,-D/2+.14,.54),(x+.25,-D/2+.14,.54)],.018,steel)
   panel('Interior light diffuser',0,-D/2+.15,H-.23,W-.35,.05,.07,light,.018)
   for i in range(9):panel('Evaporator rear vent',-.5+i*.125,D/2-.105,H-.5,.045,.02,.22,darksteel,.008)
   panel('Digital temperature control',0,D/2-.14,H-.86,.38,.04,.16,darksteel,.015)
   for x in[-.09,.09]:panel('Temperature display segments',x,D/2-.17,H-.85,.035,.008,.09,light,.002)
  if typ=='cabinet':
   for x in[-W/6,W/6]:panel('Vertical cubby divider',x,0,H/2,.13,D-.12,H-.2,wood,.02)
   for x in[-W/3,0,W/3]:
    panel('Lower framed drawer',x,-D/2-.025,.30,W/3-.16,.16,.38,wood,.035)
    curve('Drawer brass pull',[(x-.18,-D/2-.13,.32),(x+.18,-D/2-.13,.32)],.022,brass)
  else:
   for sign in[-1,1]:door(t,sign,m,typ=='glass',isfridge)
  if typ=='wardrobe':
   curve('Clothes rail',[(-W/2+.3,0,H-.45),(W/2-.3,0,H-.45)],.035,steel)
   for x in[-1,0,1]:
    curve('Wooden hanger',[(x,0,H-.7),(x-.35,0,H-1.0),(x+.35,0,H-1.0),(x,0,H-.7)],.022,wood,True)
    curve('Hanger hook',[(x,0,H-.7),(x,0,H-.43),(x+.07,0,H-.4)],.014,steel)
  if typ=='locker':
   for x in[-W/4,W/4]:
    for z in[H-.65,H-.5,H-.35]:panel('Louver ventilation',x,-D/2+.08,z,W*.25,.04,.055,darksteel,.008)
 elif stack:
  mat=wood if typ=='crate' else cream if typ=='freezer' else jarGlass if typ=='bin' else green
  panel('Container interior bottom',0,0,.155,W-.13,D-.13,.13,mat,.035)
  if typ in ['crate','basket']:
   for z in [(.35+i*.42)for i in range(int(H/.42))]:
    for y in[-D/2,D/2]:panel('Wooden slat' if typ=='crate' else 'Woven horizontal band',0,y,z,W,.09,.28 if typ=='crate' else .07,wood if typ=='crate' else thread,.015)
    for x in[-W/2,W/2]:panel('Side slat',x,0,z,.09,D,.28 if typ=='crate' else .07,wood if typ=='crate' else thread,.015)
   if typ=='basket':
    for i in range(int(W/.18)):
     for y in[-D/2,D/2]:curve('Wicker vertical weave', [(-W/2+i*.18,y+.02*sin(j*1.7),.15+j*H/18)for j in range(19)],.025,thread)
   else:
    for x in[-W/2+.15,W/2-.15]:
     for y in[-D/2-.06,D/2+.06]:panel('Corner reinforcement',x,y,H/2,.18,.035,H,green,.008)
  else:
   for y in[-D/2,D/2]:panel('Thick insulated container wall' if typ=='freezer' else 'Moulded container side',0,y,H/2,W,.16 if typ=='freezer' else .07,H,mat,.06)
   for x in[-W/2,W/2]:panel('Container end',x,0,H/2,.16 if typ=='freezer' else .07,D,H,mat,.06)
  for y in[-D/2,D/2]:panel('Rounded top rim',0,y,H,W+.12,.15,.13,cream if typ=='freezer' else wood if typ=='crate' else mat,.04)
  for x in[-W/2,W/2]:panel('Rounded side rim',x,0,H,.15,D,.13,mat,.04)
  for x in[-W/2+.25,W/2-.25]:
   for y in[-D/2+.25,D/2-.25]:cyl('Rubber foot',(x,y,.07),.13,.14,darksteel,16)
  if typ in ['freezer','chest']:
   before=set(bpy.data.objects)
   panel('Insulated sculpted lid',0,0,.08,W,.19 if False else D,.18,mat,.08)
   panel('Lid inner recess',0,0,-.035,W-.28,D-.28,.06,cream if typ=='freezer' else greenlight,.04)
   for y in[-D/2+.16,D/2-.16]:panel('Lid rubber seal',0,y,-.075,W-.30,.035,.035,darksteel,.01)
   for x in[-W/2+.16,W/2-.16]:panel('Lid rubber end seal',x,0,-.075,.035,D-.3,.035,darksteel,.01)
   curve('Lid pull handle',[(-.38,-D/2+.12,.16),(-.38,-D/2+.12,.25),(.38,-D/2+.12,.25),(.38,-D/2+.12,.16)],.032,steel)
   from mathutils import Matrix
   origin=Vector((0,D/2,H));rot=Matrix.Rotation(-1.2,4,'X')
   for o in set(bpy.data.objects)-before:o.matrix_world=Matrix.Translation(origin)@rot@Matrix.Translation((0,-D/2,0))@o.matrix_world
   for x in[-W*.32,W*.32]:panel('Metal lid hinge',x,D/2+.06,H-.1,.25,.12,.24,steel,.025)
   if typ=='freezer':
    panel('Recessed temperature panel',W*.29,-D/2-.09,.52,1,.035,.4,darksteel,.035)
    cyl('Thermostat knob',(W*.30,-D/2-.125,.52),.10,.035,cream,32,(pi/2,0,0))
    panel('Power indicator',W*.24,-D/2-.13,.52,.04,.02,.06,light,.006)
    for i in range(10):panel('Compressor ventilation',-W*.38+i*.14,-D/2-.09,.43,.06,.02,.42,darksteel,.01)
    # Interior hanging wire basket at one end, leaves the placement floor clear.
    for y in[-D*.32,D*.32]:curve('Wire basket side',[(W*.23,y,H-.15),(W*.23,y,H-.65),(W*.43,y,H-.65),(W*.43,y,H-.15)],.018,steel)
    for i in range(6):curve('Wire basket base',[(W*.23,-D*.32+i*D*.128,H-.65),(W*.43,-D*.32+i*D*.128,H-.65)],.012,steel)
  if typ=='bin':
   for x in[-W/2,W/2]:panel('Snap latch',x,0,H-.2,.14,.65,.30,green,.04)
 print('MADE furniture',typ,flush=True)

# Apply the actual modeling modifiers; merge by material, then generate a separate
# distant LOD. The high-detail version remains available for the focused cabinet.
summary=[]
for key,root in list(roots.items()):
 for o in [o for o in bpy.data.objects if o.parent==root and o.type in {'MESH','CURVE'}]:
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH')
  for mod in list(o.modifiers):
   try:bpy.ops.object.modifier_apply(modifier=mod.name)
   except Exception:pass
 by={}
 for o in list(bpy.data.objects):
  if o.parent==root and o.type=='MESH':by.setdefault(tuple(m.name for m in o.data.materials),[]).append(o)
 for mats,objects in by.items():
  bpy.ops.object.select_all(action='DESELECT')
  for o in objects:o.select_set(True)
  bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join();objects[0].name=key+'__'+mats[0];objects[0].parent=root
 meshes=[o for o in bpy.data.objects if o.parent==root and o.type=='MESH']
 tris=sum(sum(len(p.vertices)-2 for p in o.data.polygons)for o in meshes)
 summary.append({'id':key,'triangles':tris,'parts':len(meshes)})
 # High detail still uses the authored curves, but drop imperceptible coplanar
 # tessellation in large meshes before exporting. No changing silhouettes to boxes.
 for o in meshes:
  if len(o.data.polygons)>2000:
   bpy.context.view_layer.objects.active=o;d=o.modifiers.new('Runtime detail budget','DECIMATE');d.ratio=.6 if key in approved else .5
   bpy.ops.object.modifier_apply(modifier=d.name)
 # Separate low-poly model for the warehouse-wide view.
 lod=bpy.data.objects.new(key+'__far',None);bpy.context.collection.objects.link(lod)
 for o in meshes:
  c=o.copy();c.data=o.data.copy();bpy.context.collection.objects.link(c);c.parent=lod
  if len(c.data.polygons)>64:
   bpy.context.view_layer.objects.active=c;d=c.modifiers.new('Distant silhouette LOD','DECIMATE');d.ratio=.18 if key in catalog['furniture'] else .25
   bpy.ops.object.modifier_apply(modifier=d.name)
 print('PACKED',key,tris,flush=True)
BASE.joinpath('production/asset-report.json').write_text(json.dumps(summary,indent=2))
bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'production/warehouse-complete.blend'))
bpy.ops.object.select_all(action='SELECT')
bpy.ops.export_scene.gltf(filepath=str(BASE/'assets/warehouse-complete.glb'),export_format='GLB',use_selection=True,export_apply=True,export_yup=True,export_image_format='JPEG',export_image_quality=88,export_extras=True,export_cameras=False,export_lights=False)
print('COMPLETE',len(summary),flush=True)
