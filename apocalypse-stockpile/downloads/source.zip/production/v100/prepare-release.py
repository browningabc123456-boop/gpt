from pathlib import Path
import json,hashlib,zipfile,html,shutil,re
from datetime import datetime,timezone
p=Path(__file__).resolve().parents[2];out=p/'dist';r=p/'results';d=out/'downloads';d.mkdir(exist_ok=True)
mobile=json.loads((r/'v090-mobile-checks.json').read_text());platform=json.loads((r/'v080-platform-checks.json').read_text());extra=json.loads((r/'v100-release-checks.json').read_text());smoke=json.loads((r/'v100-smoke.json').read_text())
assert all(x['pass'] for x in mobile['checks']+platform['checks']+extra['checks']) and not smoke['errors']
artifact=json.loads((r/'v100-package-checks.json').read_text()) if (r/'v100-package-checks.json').exists() else {'checks':[]}
assert all(x['pass'] for x in artifact['checks'])
files=[out/'index.html',*[out/'assets'/n for n in ['game.js','boot.js','gear-models.js','detail-models.js','style.css','thumbs.css','thumbs.webp','food-preview.webp','surfaces.jpg','surface-normal.jpg','THREE-LICENSE.txt','AUDIO-LICENSE.txt']],*sorted((out/'assets').glob('place-*.wav')),*[out/'assets'/('food-'+str(i)+'.webp') for i in range(8)],*[out/'assets'/('scene-'+s+'.webp') for s in ['granary','rain','forest','coast']]]
with zipfile.ZipFile(out/'xhs-candidate.zip','w',zipfile.ZIP_DEFLATED,9)as z:
 for f in files:z.write(f,f.relative_to(out))
with zipfile.ZipFile(out/'xhs-candidate.zip')as z:
 assert z.testzip()is None and sum(n.endswith('.html')for n in z.namelist())==1
 for n in ['game.js','boot.js','gear-models.js','detail-models.js']:assert z.read('assets/'+n)==(out/'assets'/n).read_bytes()
for name in ['xhs-candidate.zip','web-offline.zip','xhs-upload-v0100.zip']:shutil.copyfile(out/'xhs-candidate.zip',d/name)
sha=hashlib.sha256((out/'assets/game.js').read_bytes()).hexdigest();zipsha=hashlib.sha256((out/'xhs-candidate.zip').read_bytes()).hexdigest()
fixes=[('开场选项多、等待高清资源太久','正常加载只显示进度。首屏仅载入轻量食品图、家具模型和材质；高清食品图逐步补载，生活物资和精细模型按需准备。高清图失败仍可继续收纳。'),('初始家具散乱','新仓库20件家具按5行4列排开，包含木架、钢架、透明柜、网架、冰箱、冷柜等；有全仓库入口和一键规整，旧自定义布局保留。'),('袋装声音太小','袋装拟音波形和播放音量单独提高；玻璃瓶、塑料瓶声音文件及播放音量保持原样。'),('缺少场景变化','新增暖木粮仓、雨夜仓库、林间储藏室、海边物资站，切换墙面、窗景、地面和光色；物资与家具保留，场景偏好自动保存。'),('小红书小工具压缩包','根目录单一index.html入口，assets内资源本地齐备，包含高清补载与额外模型包，无需远程图片、字体或API。候选包尚待真实平台接收与审核。')]
limits='验证为Chromium触控模拟、软件GPU、WebGL1、严格离线CSP和模拟小红书Storage接口；非Android/iOS真机FPS或官方小红书审核。食物为写实2.5D图片，储物家具与仓库空间为3D。'
checks=18+len(mobile['checks'])+len(platform['checks'])+len(extra['checks'])+len(artifact['checks'])
report={'version':'0.10.0','updated_utc':datetime.now(timezone.utc).isoformat(),'sha256':sha,'zip_sha256':zipsha,'rule_checks':18,'checks_total':checks,'mobile_checks':mobile['checks'],'platform_checks':platform['checks'],'release_checks':extra['checks'],'package_checks':artifact['checks'],'smoke':smoke,'fixes':[{'problem':a,'change':b}for a,b in fixes],'limits':limits}
(out/'test-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
style='body{font:15px/1.85 system-ui;color:#263b35;background:#f8f5ec;max-width:1000px;margin:24px auto;padding:0 20px}h1{font-size:25px}h2{font-size:20px;margin-top:30px}p{color:#607364}a{color:#31534a}li{margin-bottom:14px}img{width:100%;border-radius:10px}figure{margin:0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:24px}code{font-size:11px;word-break:break-all}'
head=lambda title:'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>'+style+'</style>'
links='<p><a href="./?v=0.10.0">打开游戏</a>　<a href="art-update.html">运行截图</a>　<a href="test-report.html">测试记录</a>　<a href="downloads/xhs-upload-v0100.zip">小红书候选包 ZIP</a></p>'
(out/'test-report.html').write_text(head('v0.10.0 更新与测试')+'<h1>我在末日前囤物资 · v0.10.0</h1>'+links+'<h2>改动</h2><ul>'+''.join('<li><b>'+html.escape(a)+'</b><p>'+html.escape(b)+'</p></li>'for a,b in fixes)+'</ul><h2>通过的检查：'+str(checks)+'项</h2><ul>'+''.join('<li>'+html.escape(x['name'])+'</li>'for x in extra['checks']+artifact['checks'])+'</ul><p>另有18组规则、19项触控、2组WebGL1及原生存储模拟检查。</p><h2>范围</h2><p>'+limits+'</p><p>游戏构建指纹</p><code>'+sha+'</code><p>候选包指纹</p><code>'+zipsha+'</code></html>')
shots=[('preview-v100.webp','20件家具的初始规整布局')]+[('view-'+s+'-v100.webp',name)for s,name in [('granary','暖木粮仓'),('rain','雨夜仓库'),('forest','林间储藏室'),('coast','海边物资站')]]
assert all((out/'assets'/name).is_file()for name,_ in shots)
(out/'art-update.html').write_text(head('四种仓库场景 · 实际运行截图')+'<h1>四种仓库场景</h1>'+links+'<p>以下均为游戏实际运行截图。</p><div class="grid">'+''.join('<figure><img loading="lazy" src="assets/'+name+'" alt="'+label+'"><figcaption>'+label+'</figcaption></figure>'for name,label in shots)+'</div></html>')
(d/'README.txt').write_text('我在末日前囤物资 v0.10.0\n\n小红书小工具离线候选包：xhs-upload-v0100.zip\n根目录仅index.html入口，所有必要资源在assets目录；无需远程API、图片或字体。上传ZIP原文件，不要只上传HTML，也不要多套一层文件夹。实际平台接收、运行与审核仍待上传后验证，非官方已通过包。\n首次加载不等待高清细节；20件家具按5行排齐，四种仓库场景可切换，袋装物品声音增强。192种食物、68种生活物资、15类家具，保留堆叠/整排横划/纵列长按。\n网页离线包需在HTTP服务或平台资源环境打开。\n')
source=[*sorted((p/'src').glob('*.js')),p/'assets/library.json',p/'assets/food-library.json',*sorted((p/'assets/optimized').glob('*')),*[p/n for n in ['package.json','package-lock.json','build.mjs','test.mjs','generate-audio.py','ART-DIRECTION.md','production/README.md']],*sorted((p/'production/v080').glob('*.mjs')),*sorted((p/'production/v080').glob('*.cjs')),*[f for f in (p/'production/v090').rglob('*')if f.is_file()and not f.name.endswith('.v080')],*[f for f in (p/'production/v100').rglob('*')if f.is_file()]]
with zipfile.ZipFile(d/'source.zip','w',zipfile.ZIP_DEFLATED,9)as z:
 for f in source:z.write(f,f.relative_to(p))
 for f in files:
  if f.name not in ['game.js','boot.js','gear-models.js','detail-models.js','surfaces.jpg','surface-normal.jpg','food-preview.webp',*[f'food-{i}.webp'for i in range(8)]]:z.write(f,Path('dist')/f.relative_to(out))
 z.writestr('README.md','npm ci && npm run build。含源码、已打包原始模型/食物数据、首屏轻量资产、测试脚本和离线资源。普通构建无需Blender、原始生成PNG或Sharp。重制首屏预览图需Sharp；重制拟音需FFmpeg。')
js=(out/'assets/game.js').read_text()+''.join((out/'assets'/n).read_text()for n in ['boot.js','gear-models.js','detail-models.js'])
forbidden={n:len(re.findall(pattern,js))for n,pattern in{'worker':r'new\s+Worker\s*\(','wasm':r'WebAssembly\.','eval':r'\beval\s*\(','dynamic_function':r'new\s+Function\s*\(','fetch':r'\bfetch\s*\('}.items()};assert not any(forbidden.values()),forbidden
release={'version':'0.10.0','runtime_files':len(files),'runtime_js_bytes':(out/'assets/game.js').stat().st_size,'boot_js_bytes':(out/'assets/boot.js').stat().st_size,'candidate_bytes':(out/'xhs-candidate.zip').stat().st_size,'checks':checks,'sha256':sha,'zip_sha256':zipsha,'forbidden_runtime_apis':forbidden}
(r/'release-v100.json').write_text(json.dumps(release,indent=2));print(json.dumps(release))
