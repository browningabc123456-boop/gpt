import sharp from '/workspace/work/shelter-sample/tools/node_modules/sharp/dist/index.mjs';
import{readFile,writeFile,mkdir}from'node:fs/promises';
await mkdir('assets/optimized',{recursive:true});const library=JSON.parse(await readFile('assets/library.json','utf8')),art=JSON.parse(await readFile('assets/food-library.json','utf8')),layers=[],rects={};
const sheets=art.sheets.map(s=>Buffer.from(s.split(',')[1],'base64'));
for(const [id,r]of Object.entries(art.rects)){const sheet=r.sheet,col=r.icon[0]/128,row=r.icon[1]/128,x=Math.round(r.uv[0]*1536),y=Math.round((1-r.uv[1]-r.uv[3])*1024),w=Math.round(r.uv[2]*1536),h=Math.round(r.uv[3]*1024),sprite=await sharp(sheets[sheet]).extract({left:x,top:y,width:w,height:h}).resize(56,56,{fit:'inside'}).png().toBuffer(),m=await sharp(sprite).metadata(),left=col*64+Math.floor((64-m.width)/2),top=row*64+Math.floor((64-m.height)/2);layers.push({input:sprite,left,top});rects[id]=[left/1024,1-(top+m.height)/768,m.width/1024,m.height/768];}
await sharp({create:{width:1024,height:768,channels:4,background:{r:0,g:0,b:0,alpha:0}}}).composite(layers).webp({quality:78,alphaQuality:95,effort:6}).toFile('assets/optimized/food-preview.webp');
await writeFile('assets/optimized/preview-rects.json',JSON.stringify(rects));
for(const[key,name,size,quality]of[['atlas','surfaces.jpg',1024,72],['normal','surface-normal.jpg',512,60]])await sharp(Buffer.from(library[key].split(',')[1],'base64')).resize(size,size,{fit:'fill'}).jpeg({quality,mozjpeg:true}).toFile('assets/optimized/'+name);
console.log('Built small shared food preview and furniture textures.');
