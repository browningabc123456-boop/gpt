import sharp from '/workspace/work/shelter-sample/tools/node_modules/sharp/dist/index.mjs';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
const furnitureIds=new Set(['wood','metal','cabinet','fridge','freezer','partition','pegboard','wardrobe','glass','crate','chest','bin','wire','locker','basket']);
const iconLayers=[];const root='/workspace/work/shelter',spec=JSON.parse(await readFile(root+'/production/v080/foods.json','utf8')),sheets=[],rects={};await mkdir(root+'/dist/assets',{recursive:true});
for(let sheet=0;sheet<8;sheet++){
 const input=root+'/assets/food-art/sheet-'+sheet+'.png',im=sharp(input),{data,info}=await im.ensureAlpha().raw().toBuffer({resolveWithObject:true}),W=info.width,H=info.height;
 const gpuLayers=[];
 for(const p of spec.groups[sheet].items){const col=p.artCell%6,row=Math.floor(p.artCell/6),x0=Math.floor(col*W/6),x1=Math.floor((col+1)*W/6),y0=Math.floor(row*H/4),y1=Math.floor((row+1)*H/4);let minX=x1,minY=y1,maxX=x0,maxY=y0,n=0;
  for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++)if(data[(y*W+x)*4+3]>48){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);n++;}
  if(n<150)throw Error('Empty food cell '+p.id);
  // Analyze connected alpha components only to choose the product's UV bounds.
  // The original source pixels are preserved; tiny neighboring-cell fragments
  // must not become part of the selected sprite rectangle.
  const cw=x1-x0,ch=y1-y0,seen=new Uint8Array(cw*ch),queue=new Int32Array(cw*ch),components=[];
  for(let sy=0;sy<ch;sy++)for(let sx=0;sx<cw;sx++){const start=sy*cw+sx;if(seen[start]||data[((sy+y0)*W+sx+x0)*4+3]<=48)continue;let head=0,tail=0,l=sx,r=sx,t=sy,b=sy;queue[tail++]=start;seen[start]=1;while(head<tail){const at=queue[head++],xx=at%cw,yy=Math.floor(at/cw);l=Math.min(l,xx);r=Math.max(r,xx);t=Math.min(t,yy);b=Math.max(b,yy);for(const k of[xx>0?at-1:-1,xx<cw-1?at+1:-1,yy>0?at-cw:-1,yy<ch-1?at+cw:-1])if(k>=0&&!seen[k]&&data[((Math.floor(k/cw)+y0)*W+k%cw+x0)*4+3]>48){seen[k]=1;queue[tail++]=k;}}components.push({n:tail,l,r,t,b});}
  const biggest=Math.max(...components.map(c=>c.n)),keep=components.filter(c=>c.n>=Math.max(24,biggest*.04));minX=x0+Math.min(...keep.map(c=>c.l));maxX=x0+Math.max(...keep.map(c=>c.r));minY=y0+Math.min(...keep.map(c=>c.t));maxY=y0+Math.max(...keep.map(c=>c.b));
minX=Math.max(x0,minX-2);minY=Math.max(y0,minY-2);maxX=Math.min(x1-1,maxX+2);maxY=Math.min(y1-1,maxY+2);
  const w=maxX-minX+1,h=maxY-minY+1;const sprite=await sharp(input).extract({left:minX,top:minY,width:w,height:h}).resize(224,224,{fit:'inside'}).png().toBuffer(),meta=await sharp(sprite).metadata(),gpuX=col*256+Math.floor((256-meta.width)/2),gpuY=row*256+Math.floor((256-meta.height)/2);gpuLayers.push({input:sprite,left:gpuX,top:gpuY});const iconIndex=sheet*24+p.artCell,icon=await sharp(input).extract({left:minX,top:minY,width:w,height:h}).resize(120,120,{fit:'contain',background:{r:0,g:0,b:0,alpha:0}}).png().toBuffer();iconLayers.push({input:icon,left:iconIndex%16*128+4,top:Math.floor(iconIndex/16)*128+4});rects[p.id]={icon:[iconIndex%16*128,Math.floor(iconIndex/16)*128,128,128],sheet,x:minX,y:minY,w,h,W,H,uv:[gpuX/1536,1-(gpuY+meta.height)/1024,meta.width/1536,meta.height/1024],coverage:n/((x1-x0)*(y1-y0))};
 }
 const out=await sharp({create:{width:1536,height:1024,channels:4,background:{r:0,g:0,b:0,alpha:0}}}).composite(gpuLayers).webp({quality:88,alphaQuality:100,effort:6}).toBuffer();await writeFile(root+'/dist/assets/food-'+sheet+'.webp',out);sheets.push('data:image/webp;base64,'+out.toString('base64'));
}
await sharp({create:{width:2048,height:1536,channels:4,background:{r:0,g:0,b:0,alpha:0}}}).composite(iconLayers).webp({quality:88,alphaQuality:100,effort:6}).toFile(root+'/dist/assets/food-icons.webp');
await writeFile(root+'/assets/food-library.json',JSON.stringify({sheets,rects}));await writeFile(root+'/production/v080/art-rects.json',JSON.stringify(rects,null,2));
const old=JSON.parse(await readFile(root+'/production/v080/library-v070.json','utf8')),food=new Set(spec.items.map(p=>p.id));for(const key of Object.keys(old.entries))if(food.has(key.replace(/__far$/,''))||(!key.endsWith('__far')&&!furnitureIds.has(key)))delete old.entries[key];await writeFile(root+'/assets/library.json',JSON.stringify(old));console.log({foodImages:Object.keys(rects).length,atlasBytes:sheets.reduce((n,s)=>n+s.length,0),keptLegacyMeshes:Object.keys(old.entries).length,legacyBytes:JSON.stringify(old).length});
