from pathlib import Path
import json, hashlib, zipfile, html, shutil, re
from datetime import datetime, timezone
p=Path(__file__).resolve().parents[2]; out=p/'dist'; r=p/'results'; d=out/'downloads'; d.mkdir(exist_ok=True)
mobile=json.loads((r/'v080-mobile-checks.json').read_text())
platform=json.loads((r/'v080-platform-checks.json').read_text())
smoke=json.loads((r/'v080-smoke.json').read_text())
assert all(x['pass'] for x in mobile['checks']+platform['checks']) and not smoke['errors']
fixes=[
('食物种类不足','食品扩充至192种，8个食品分类；加上68种原有生活物资，共260种可放置物资。'),
('食物几何造型偏离确认图册','192种食物改用透明写实图片，作为场景和菜单的实际运行素材；仓库增加暖木、雨窗和绿架背景。食物采用2.5D方式，家具仍为可操作的3D物件。'),
('食物与家具大小失衡、层高浪费','按实物宽高深度设置尺寸，重设15类家具尺寸并按实际层高重建层板。普通架柜可调3–8层；默认钢架支持三层罐头或两层常见干粮袋接近填满。'),
('只有箱体能堆叠，横划无法增加一层','所有15类储物家具共用堆叠规则；划过已有一排即整排加一层，长按继续纵列摆放。检查支撑面积与层高，满层不会穿过层板。整次手势可一次撤销。'),
('旧存档尺寸变更与保存体积','v3/v4迁移至v5保留位置、方向、物品及堆叠；暂时放不下的留在待恢复区。压缩并校验v5存档，旧档键保持可回退。'),
('手机卡片和图片边缘问题','修复图集相邻单元的碎片、SVG留白露出邻图、手机名称被裁切；预制缩略图带版本缓存，食品实例化与局部重绘减少几何负担。')]
limits='测试为Chromium手机触控模拟、软件GPU、WebGL1、严格离线CSP及模拟小红书Storage接口。未进行Android/iOS真机FPS、真实小红书容器验收或官方审核。食物是写实图片构成的2.5D资产，不是全角度写实3D模型；远处背景物资属于装饰图片。'
sha=hashlib.sha256((out/'assets/game.js').read_bytes()).hexdigest()
report={'version':'0.8.0','updated_utc':datetime.now(timezone.utc).isoformat(),'sha256':sha,'food_count':192,'item_count':260,'furniture_types':15,'rule_checks':8,'mobile_checks':mobile['checks'],'platform_checks':platform['checks'],'smoke':smoke,'fixes':[{'problem':a,'change':b} for a,b in fixes],'limits':limits}
(out/'test-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
style='body{font:15px/1.85 system-ui;color:#263b35;background:#f8f5ec;max-width:1000px;margin:24px auto;padding:0 20px}h1{font-size:25px}h2{font-size:20px;margin-top:30px}p{color:#607364}a{color:#31534a}li{margin-bottom:14px}img{width:100%;border-radius:12px}figure{margin:0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:24px}code{font-size:11px;word-break:break-all}'
head=lambda title:'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>'+style+'</style>'
links='<p><a href="./?v=0.8.0">打开新版游戏</a>　<a href="art-update.html">实际游戏截图</a>　<a href="test-report.html">改动和测试记录</a></p>'
chinese=['食品分类图片加载','横划12摞整排加层','再次横划叠至第三层','满层拒绝溢出','整排一次撤销','清空普通架全部层','撤销清空精确恢复','调整层板保留库存','层板调整可撤销','短点按仅加一件','长按纵列含已有堆叠','纵列一次撤销','压缩存档重开恢复','单指镜头转动','双指平移缩放不误放','新食物跨分类搜索','小屏幕场景可操作','离线CSP无外部请求及缺图']
(out/'test-report.html').write_text(head('v0.8.0 改动与测试')+'<h1>我在末日前囤物资 · v0.8.0</h1>'+links+'<h2>这次改了什么</h2><ul>'+''.join('<li><b>'+html.escape(a)+'</b><p>'+html.escape(b)+'</p></li>' for a,b in fixes)+'</ul><h2>已通过的检查</h2><p>8组规则检查、18项触控浏览器检查、2组WebGL1及原生存储模拟检查。</p><ul>'+''.join('<li>'+html.escape(x)+'</li>' for x in chinese+[x['name'] for x in platform['checks']])+'</ul><h2>验证范围</h2><p>'+html.escape(limits)+'</p><p><a href="xhs-candidate.zip">小红书离线候选包</a>　<a href="downloads/source.zip">运行源码</a></p><p>游戏构建SHA-256</p><code>'+sha+'</code></html>')
shots=[('v080-first.png','preview-v080.png','写实食品与密集叠放'),('v080-wood.png','wood-v080.png','长木货架'),('v080-fridge.png','fridge-v080.png','冰箱与六层生鲜储物')]
for source,dest,label in shots: shutil.copyfile(r/source,out/'assets'/dest)
(out/'art-update.html').write_text(head('v0.8.0 实际游戏截图')+'<h1>写实食品 · 新版实际运行截图</h1>'+links+'<p>这里展示游戏浏览器截图，未使用概念图代替运行结果。192种写实食物以2.5D形式放入可操作的3D架柜。</p><div class="grid">'+''.join('<figure><img loading="lazy" src="assets/'+dest+'" alt="'+label+'"><figcaption>'+label+'</figcaption></figure>' for _,dest,label in shots)+'</div></html>')
files=[out/'index.html',out/'assets/game.js',out/'assets/style.css',out/'assets/thumbs.css',out/'assets/thumbs.webp',out/'assets/THREE-LICENSE.txt',*sorted((out/'assets').glob('*.wav')),out/'assets/food-icons.webp']
with zipfile.ZipFile(out/'xhs-candidate.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for f in files: z.write(f,f.relative_to(out))
with zipfile.ZipFile(out/'xhs-candidate.zip') as z:
 assert z.testzip() is None and sum(n.endswith('.html') for n in z.namelist())==1
 assert z.read('assets/game.js')==(out/'assets/game.js').read_bytes()
 assert 'assets/food-icons.webp' in z.namelist()
for name in ['xhs-candidate.zip','web-offline.zip']: shutil.copyfile(out/'xhs-candidate.zip',d/name)
(d/'README.txt').write_text('我在末日前囤物资 v0.8.0\n192种写实食物、68种生活物资、15类家具；所有家具支持叠放与横划整排加层。物资按实物比例设置，普通家具可调整层数。\n清空保留家具并可撤销；旧存档升级保留物品，未能放下的进入待恢复区。\n单指收纳/长按纵列/横划整排；镜头模式单指转动，双指平移缩放转向。\n食物为2.5D写实图片，家具为3D。离线候选包不是官方审核通过包，仍待真实小红书容器、Android/iOS真机验证。\n')
source=[*sorted((p/'src').glob('*.js')),*[p/'assets'/n for n in ['library.json','food-library.json','room-art.json']],*[p/n for n in ['package.json','package-lock.json','build.mjs','test.mjs','ART-DIRECTION.md','production/README.md','production/thumbs.cjs']],*sorted((p/'production/v080').glob('*.mjs')),*sorted((p/'production/v080').glob('*.cjs')),p/'production/v080/foods.py',p/'production/v080/foods.json',p/'production/v080/art-rects.json',Path(__file__).resolve()]
with zipfile.ZipFile(d/'source.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for f in source: z.write(f,f.relative_to(p))
 for f in files:
  if f.name!='game.js': z.write(f,Path('dist')/f.relative_to(out))
 z.writestr('README.md','npm ci && npm run build。包含运行源码、已打包资产、测试和离线资源。原始生成PNG与Blender工程保留在工作区；常规构建无需重制图片或运行Blender。测试脚本的浏览器依赖需另装。')
js=(out/'assets/game.js').read_text()
forbidden={n:len(re.findall(pattern,js)) for n,pattern in {'worker':r'new\s+Worker\s*\(','wasm':r'WebAssembly\.','eval':r'\beval\s*\(','dynamic_function':r'new\s+Function\s*\(','fetch':r'\bfetch\s*\('}.items()}
assert not any(forbidden.values()),forbidden
release={'version':'0.8.0','runtime_files':len(files),'runtime_js_bytes':(out/'assets/game.js').stat().st_size,'candidate_bytes':(out/'xhs-candidate.zip').stat().st_size,'checks':28,'sha256':sha,'forbidden_runtime_apis':forbidden}
(r/'release-v080.json').write_text(json.dumps(release,indent=2)); print(json.dumps(release))
