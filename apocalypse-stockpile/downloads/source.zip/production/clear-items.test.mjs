import test from 'node:test';
import assert from 'node:assert/strict';
import {fresh,place,clearItems,totals,validate} from '../src/core.js';
test('clear removes shelf items, all stack layers and recovered loose stock; leaves exact layout/settings restorable',()=>{
 const s=fresh();s.night=true;s.muted=true;
 assert.ok(place(s,'f1',0,'water'));assert.ok(place(s,'f6',0,'fish'));assert.ok(place(s,'f6',0,'fish'));assert.ok(place(s,'f9',0,'rice'));s.migrationUnplaced=['pot'];
 const before=JSON.stringify(s),layout=s.furniture.map(({slots,piles,...f})=>f);
 assert.equal(clearItems(s),5);assert.equal(totals(s).count,0);assert.ok(s.furniture.every(f=>f.slots.every(x=>x===null)&&Object.keys(f.piles).length===0));assert.deepEqual(s.furniture.map(({slots,piles,...f})=>f),layout);assert.deepEqual(s.migrationUnplaced,[]);assert.equal(s.night,true);assert.equal(s.muted,true);assert.ok(validate(s));assert.equal(clearItems(s),0);
 const restored=JSON.parse(before);assert.ok(validate(restored));assert.equal(totals(restored).count,4);assert.equal(restored.furniture[5].piles[0].length,1);
});
