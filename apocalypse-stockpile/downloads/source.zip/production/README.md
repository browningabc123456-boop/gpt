# v0.10.0 photo-food production

192 photo food cutouts are real runtime assets, not reference images translated back into primitive meshes. These are camera-facing 2.5D objects in an interactive 3D warehouse. Existing authored 3D furniture and 68 non-food supplies remain. Do not describe the food as all-angle sculpted/photogrammetry models.

Build with `npm ci && npm run build`. Packed mesh geometry and food rectangles are embedded; build.mjs extracts the GPU images into local files in dist/assets. The small boot.js runs before the engine download. No room photograph is used. No runtime downloads, fonts, workers, WASM or remote services.

Art repacking: `python production/v080/foods.py`, `node production/v080/pack-art.mjs`, `node production/v080/pack-room.mjs`. The latter two require original generated PNGs in assets/food-art and sharp available in the earlier sample tools folder. Original generated PNGs and old-library backups are preserved in the workspace rather than repeated in the downloadable runtime source ZIP. Repacking is not needed for ordinary code edits/builds. The legacy Blender authoring scripts are retained for non-food and furniture work.

Food GPU atlases use alpha-selected connected components, padded cells and per-instance UV rectangles. UI icons use normalized cells and explicit SVG clipping. Furniture layer geometry and wood UVs are rebuilt at physical dimensions. All furniture supports height-limited stacks, support-area checks, grouped row/depth gestures and adjustable non-deep shelf counts. Fine-grid v5 saves use checked compressed JSON; migration retains the old v4 key and queues anything that cannot yet fit.

Validation: `npm test` (18 rule groups). With a local dist preview server on 8088, `node production/v090/interaction-check.cjs` (19 checks), `node production/v080/platform-check.cjs` (2 grouped WebGL1/native-storage checks), `node production/v100/release-check.cjs` (21 startup/layout/scene checks), `node production/v100/shots.cjs` (actual screenshots). Browser scripts require Playwright/Chromium installed in this workspace. They do not measure actual-phone FPS or official Xiaohongshu acceptance.

Release: `python production/v100/prepare-release.py` creates bound test reports, screenshot gallery, an offline candidate, duplicate web-offline package and source ZIP. Existing test pages and unrelated website paths are preserved during deployment.

Audio: python generate-audio.py uses the checked CC0 source takes in production/v090/foley and FFmpeg. The sources manifest and AUDIO-LICENSE.txt retain provenance. 33 softened contact samples replace the old oscillator clips; playback has rate and overlap limits. Food selection is silent.

Startup packaging: production/v100/pack-startup.mjs creates assets/optimized (requires Sharp only for rebuilding the previews). Ordinary npm run build uses those versioned files, embeds far furniture meshes, writes gear-models.js and detail-models.js, and extracts full food atlases. Food-preview.webp supplies both GPU and UI preview images. Full sheets upgrade both their material and all matching per-instance UV rectangles. Extra model loads are guarded before stock placement and before restoring saves containing gear.

Run production/v100/package-check.cjs against the actual extracted ZIP after prepare-release.py. It serves the extraction on a local port under strict CSP and verifies full images, extra models, four scene previews, scene switching and no external requests. Re-run prepare-release.py once to bind this evidence into the public report; runtime ZIP bytes stay identical. Candidate ZIP is single-entry offline content, still awaiting real Xiaohongshu upload/review.
