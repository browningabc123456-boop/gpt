# v0.8.0 photo-food production

192 photo food cutouts are real runtime assets, not reference images translated back into primitive meshes. These are camera-facing 2.5D objects in an interactive 3D warehouse. Existing authored 3D furniture and 68 non-food supplies remain. Do not describe the food as all-angle sculpted/photogrammetry models.

Build with `npm ci && npm run build`. Packed assets/library.json, assets/food-library.json and assets/room-art.json are embedded in the bundle; the offline package includes the shared UI image sheets. No runtime downloads, fonts, workers, WASM or remote services.

Art repacking: `python production/v080/foods.py`, `node production/v080/pack-art.mjs`, `node production/v080/pack-room.mjs`. The latter two require original generated PNGs in assets/food-art and sharp available in the earlier sample tools folder. Original generated PNGs and old-library backups are preserved in the workspace rather than repeated in the downloadable runtime source ZIP. Repacking is not needed for ordinary code edits/builds. The legacy Blender authoring scripts are retained for non-food and furniture work.

Food GPU atlases use alpha-selected connected components, padded cells and per-instance UV rectangles. UI icons use normalized cells and explicit SVG clipping. Furniture layer geometry and wood UVs are rebuilt at physical dimensions. All furniture supports height-limited stacks, support-area checks, grouped row/depth gestures and adjustable non-deep shelf counts. Fine-grid v5 saves use checked compressed JSON; migration retains the old v4 key and queues anything that cannot yet fit.

Validation: `npm test` (8 rule groups). With a local dist preview server on 8088, `node production/v080/mobile-check.cjs` (18 checks), `node production/v080/platform-check.cjs` (2 grouped WebGL1/native-storage checks), `node production/v080/smoke.cjs` (actual screenshots). Browser scripts require Playwright/Chromium installed in this workspace. They do not measure actual-phone FPS or official Xiaohongshu acceptance.

Release: `python production/v080/prepare-release.py` creates bound test reports, screenshot gallery, an offline candidate, duplicate web-offline package and source ZIP. Existing test pages and unrelated website paths are preserved during deployment.
