# Full warehouse art rollout v0.7.0

The eight approved Blender source assets are carried forward, with 112 further item models and 14 further furniture models. The game loads this asset library rather than src/models.js. Source modeling remains scripted Blender mesh authoring; it is not scanning, a purchased asset pack, or automatic image-to-3D conversion. The goal is consistent silhouettes and materials with the approved live prototype.

Pipeline:
1. Export catalog and unchanged v4 physical sizes to production/catalog.json.
2. blender -b --python production/build_library.py (requires the earlier sample source/textures at ../shelter-sample).
3. node production/pack_library.mjs. Packs authored positions, normals, UVs, material parameters and indices. Original shared image sources are assembled into padded technical texture atlases. The eight approved products keep their illustrated labels. Additional printed products get category-specific Chinese labels.
4. npm run build. Geometry data is embedded in the game bundle; images use data URIs. No runtime model download, external service, WASM, worker or GLTF fetch.
5. node production/thumbs.cjs renders actual new models offline into a shared thumbnail sheet. This uses an existing local preview server on port8088.
6. node --test test.mjs production/clear-items.test.mjs; node production/game-check.cjs. See results for exact checks, software-renderer metrics and screenshots.

Rendering changes: one opaque PBR material carries per-vertex surface parameters and a normal atlas; one cheap transparent material replaces scene refraction. Each authored asset has a detailed and decimated distant version. Inventory is instanced and updated only for changed furniture; transforms move the containing group. One local shadow map updates after interaction settles. Static contact patches retain grounding. No SSAO/bloom or other full-screen multipass compositor in the full game. Thumbnails are pre-rendered and never perform GPU readback on the phone. Scene redraw stops while idle; maximum pixel ratio is reduced on small screens, with a user-facing low-quality option.

Clear all removes slots, stack layers and recovered loose stock. It keeps every furniture transform, sound setting and night setting. A confirmation counts all layers and an undo snapshot restores exact previous state. Local save key/version/footprints remain v4 so existing layouts are not silently repacked.

Validation limits: browser touch emulation and software GPU are useful for functional checks and draw/triangle budgets, not actual iOS/Android FPS. The Xiaohongshu storage interface can be simulated; actual Xiaohongshu upload specifications, device container behavior and official review require platform access. Candidate ZIP is an offline build, not proof of approval.
