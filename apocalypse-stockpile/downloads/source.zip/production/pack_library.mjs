import {NodeIO} from '/workspace/work/shelter-sample/tools/node_modules/@gltf-transform/core/dist/index.js';
import {ALL_EXTENSIONS} from '/workspace/work/shelter-sample/tools/node_modules/@gltf-transform/extensions/dist/index.js';
import sharp from '/workspace/work/shelter-sample/tools/node_modules/sharp/dist/index.mjs';
import * as T from 'three';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {deflateSync} from 'node:zlib';
const root='/workspace/work/shelter',src='/workspace/work/shelter-sample/assets';
const io=new NodeIO().registerExtensions(ALL_EXTENSIONS),doc=await io.read(root+'/assets/warehouse-complete.glb');
const names=['white','oak','linen','labels','apple','rain','canvas'],tileSize=512,atlasSize=2048,padding=8;
async function atlas(normal){const layers=[];for(let i=0;i<names.length;i++){let image;const path=normal?({oak:'oak-normal.png',linen:'terry-normal.png',canvas:'canvas-normal.png'}[names[i]]):(names[i]==='white'?null:names[i]+'.jpg');
 if(path)image=await sharp(src+'/'+path).resize(496,496).extend({top:8,left:8,bottom:8,right:8,extendWith:'copy'}).toBuffer();
 else image=await sharp({create:{width:512,height:512,channels:3,background:normal?{r:128,g:128,b:255}:{r:255,g:255,b:255}}}).png().toBuffer();
 layers.push({input:image,left:(i%4)*512,top:Math.floor(i/4)*512});}
 return await sharp({create:{width:atlasSize,height:atlasSize,channels:3,background:normal?{r:128,g:128,b:255}:{r:255,g:255,b:255}}}).composite(layers).jpeg({quality:normal?89:90,chromaSubsampling:'4:4:4'}).toBuffer();}
const [albedo,normal]=await Promise.all([atlas(false),atlas(true)]);
const catalog=JSON.parse(await readFile(root+'/production/catalog.json','utf8')),entries={};
const getTile=m=>{const name=m.getName();if(/Oak grain/.test(name))return 1;if(/Sage terry/.test(name))return 2;if(/Original packaging/.test(name))return 3;if(/Natural apple skin/.test(name))return 4;if(/Rainy/.test(name))return 5;if(/Natural cotton/.test(name))return 6;return 0;};
let totalVertices=0,totalTriangles=0;
for(const node of doc.getRoot().listScenes()[0].listChildren()){
 const id=node.getName();if(!id)continue;const parts={solid:{v:[],idx:[]},glass:{v:[],idx:[]}};
 const visit=n=>{if(n.getMesh()){const matrix=new T.Matrix4().fromArray(n.getWorldMatrix()),nm=new T.Matrix3().getNormalMatrix(matrix);
 for(const p of n.getMesh().listPrimitives()){
  const a=p.getAttribute('POSITION'),norm=p.getAttribute('NORMAL'),uv=p.getAttribute('TEXCOORD_0'),m=p.getMaterial();if(!a||!m)continue;
  const trans=m.getExtension('KHR_materials_transmission')?.getTransmissionFactor()||0,glass=trans>.6,part=parts[glass?'glass':'solid'],offset=part.v.length;
  let tile=getTile(m);const baseId=id.replace(/__far$/,''),itemIndex=catalog.items.findIndex(p=>p.id===baseId),customLabel=tile===3&&itemIndex>=0&&!['water','rice','fish','honey','apple','towel','pot','lantern'].includes(baseId);if(customLabel)tile=16+itemIndex;
  const col=m.getBaseColorFactor(),rough=m.getRoughnessFactor(),metal=m.getMetallicFactor(),em=m.getEmissiveFactor(),emission=Math.min(3,Math.max(...em)*(m.getExtension('KHR_materials_emissive_strength')?.getEmissiveStrength()||1));
  const pa=a.getArray(),na=norm?.getArray(),ua=uv?.getArray();
  for(let i=0;i<a.getCount();i++){
   const pos=new T.Vector3(pa[i*3],pa[i*3+1],pa[i*3+2]).applyMatrix4(matrix),no=new T.Vector3(na?.[i*3]??0,na?.[i*3+1]??1,na?.[i*3+2]??0).applyNormalMatrix(nm);
   let u=ua?.[i*2]||0,v=ua?.[i*2+1]||0;if(customLabel){u=((u%.5)-.006)/.488;v=((v%.5)-.006)/.488;}
   part.v.push({pos:pos.toArray(),normal:no.toArray(),uv:[u,v],color:col.slice(0,3),surface:[tile,rough,metal,emission]});
  }
  const idx=p.getIndices()?.getArray()||Array.from({length:a.getCount()},(_,i)=>i);for(const i of idx)part.idx.push(offset+i);
 }}for(const child of n.listChildren())visit(child);};visit(node);
 const all=Object.values(parts).flatMap(p=>p.v),min=[0,1,2].map(k=>Math.min(...all.map(v=>v.pos[k]))),max=[0,1,2].map(k=>Math.max(...all.map(v=>v.pos[k])));
 // Furniture retains designed placement dimensions. Supplies fit the unchanged
 // v4 save footprint and use their authored aspect ratio.
 const baseId=id.replace(/__far$/,''),item=catalog.items.find(p=>p.id===baseId);
 let scale=1;if(item)scale=Math.min(item.size.w/(max[0]-min[0]),item.size.h/(max[1]-min[1]),item.size.d/(max[2]-min[2]));
 for(const p of Object.values(parts))for(const v of p.v)if(item)v.pos=v.pos.map((x,k)=>(x-(k===1?min[k]:(min[k]+max[k])/2))*scale);
 const out=[];
 for(const [kind,p]of Object.entries(parts)){if(!p.v.length)continue;
  const lo=[0,1,2].map(k=>Math.min(...p.v.map(v=>v.pos[k]))),hi=[0,1,2].map(k=>Math.max(...p.v.map(v=>v.pos[k]))),span=hi.map((v,k)=>Math.max(.000001,v-lo[k])),stride=20,b=Buffer.alloc(p.v.length*stride);
  p.v.forEach((v,i)=>{const at=i*stride;for(let k=0;k<3;k++){b.writeUInt16LE(Math.round((v.pos[k]-lo[k])/span[k]*65535),at+k*2);b.writeInt8(Math.round(Math.max(-1,Math.min(1,v.normal[k]))*127),at+6+k);b.writeUInt8(Math.round(Math.max(0,Math.min(1,v.color[k]))*255),at+13+k);}for(let k=0;k<2;k++)b.writeUInt16LE(Math.round((Math.max(-16,Math.min(16,v.uv[k]))+16)/32*65535),at+9+k*2);b[at+16]=v.surface[0];b[at+17]=Math.round(v.surface[1]*255);b[at+18]=Math.round(v.surface[2]*255);b[at+19]=Math.round(v.surface[3]/3*255);});
  const indexBytes=p.v.length>65535?4:2,ix=Buffer.alloc(p.idx.length*indexBytes);p.idx.forEach((n,i)=>indexBytes===4?ix.writeUInt32LE(n,i*4):ix.writeUInt16LE(n,i*2));
  out.push({kind,min:lo,span,vertices:p.v.length,triangles:p.idx.length/3,indexBytes,compressed:true,data:deflateSync(b,{level:9}).toString('base64'),indices:deflateSync(ix,{level:9}).toString('base64')});totalVertices+=p.v.length;totalTriangles+=p.idx.length/3;
 }
 entries[id]=out;
}
await mkdir(root+'/assets',{recursive:true});
const lib={version:1,atlas:'data:image/jpeg;base64,'+albedo.toString('base64'),normal:'data:image/jpeg;base64,'+normal.toString('base64'),entries};
await writeFile(root+'/assets/library.json',JSON.stringify(lib));
await writeFile(root+'/production/packed-report.json',JSON.stringify({models:Object.keys(entries).length,high:Object.keys(entries).filter(k=>!k.endsWith('__far')).length,atlasBytes:albedo.length+normal.length,vertices:totalVertices,triangles:totalTriangles,libraryBytes:Buffer.byteLength(JSON.stringify(lib)),entries:Object.fromEntries(Object.entries(entries).map(([id,parts])=>[id,parts.map(p=>({kind:p.kind,vertices:p.vertices,triangles:p.triangles}))]))},null,2));
console.log({models:Object.keys(entries).length,totalVertices,totalTriangles,atlasBytes:albedo.length+normal.length,libraryBytes:Buffer.byteLength(JSON.stringify(lib))});
