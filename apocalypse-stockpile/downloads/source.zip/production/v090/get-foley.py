from pathlib import Path
import urllib.request,concurrent.futures,json,hashlib
out=Path(__file__).parent/'foley';out.mkdir(exist_ok=True)
base='https://raw.githubusercontent.com/GeorgeQLe/assets-sfx-combat/main/'
files=[f'assets/kenney/impact-sounds/Audio/{kind}_{i:03}.ogg' for kind in ['impactGlass_light','impactMetal_light','impactSoft_medium','impactWood_light','impactGeneric_light'] for i in range(3)]+['LICENSES/kenney-impact-sounds-license.txt']
def get(path):
 data=urllib.request.urlopen(base+path,timeout=30).read();name=Path(path).name;(out/name).write_bytes(data);return {'name':name,'url':base+path,'sha256':hashlib.sha256(data).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: results=list(pool.map(get,files))
(out/'sources.json').write_text(json.dumps(results,indent=2));print('Downloaded',len(results),'CC0 source files.')
