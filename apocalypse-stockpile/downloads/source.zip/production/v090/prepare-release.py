from pathlib import Path
import json, hashlib, zipfile, html, shutil, re
from datetime import datetime, timezone
p=Path(__file__).resolve().parents[2]; out=p/'dist'; r=p/'results'; d=out/'downloads'; d.mkdir(exist_ok=True)
mobile=json.loads((r/'v090-mobile-checks.json').read_text())
platform=json.loads((r/'v090-platform-checks.json').read_text())
smoke=json.loads((r/'v090-smoke.json').read_text())
assert all(x['pass'] for x in mobile['checks']+platform['checks']) and not smoke['errors']
extra=json.loads((r/'v090-release-checks.json').read_text());assert all(x['pass'] for x in extra['checks'])
fixes=[
('重复的食品图片背景显乱','去掉食品背景拼图，恢复高窗、梁柱、暖色地面和宽走道的3D大仓库；物资架柜保留写实食品素材。'),
('手机长期停在加载页','独立约2KB启动脚本先运行，主脚本约3.5MB；图片分文件加载、自动重试，并为失败和超时提供可操作入口。手机默认减少高成本效果，保留边缘平滑；存储桥接不响应也会退出等待。'),
('横屏和部分手机物品栏挡在左边','手机横竖屏、宽屏和触控设备均采用底部物品栏；用布局尺寸监听及时更新画布。删除口号、装饰副标题，保留搜索、分类和操作提示。'),
('摆放声音偏刺耳且像提示音','替换为Kenney CC0碰撞拟音，按玻璃、金属、纸袋、软食物、塑料、木器等材质区分；33段轻短声音削减尖锐高频与拖尾，控制峰值、间隔和重叠数量。'),
('缺少囤货过程反馈','新增111条品类和物品相关的幽默提示，按数量节点触发；连续整排摆放在松手后显示准确数量，15秒内不连弹，撤销或收回不显示过时提示。')]

limits='测试为Chromium手机触控模拟、软件GPU、WebGL1、严格离线CSP及模拟小红书Storage接口。未进行Android/iOS真机FPS、真实小红书容器验收或官方审核。食物是写实图片构成的2.5D资产，不是全角度写实3D模型；背景为实时3D仓库，食品图片是实际可操作库存。'
sha=hashlib.sha256((out/'assets/game.js').read_bytes()).hexdigest()
report={'version':'0.9.0','updated_utc':datetime.now(timezone.utc).isoformat(),'sha256':sha,'food_count':192,'item_count':260,'furniture_types':15,'rule_checks':13,'mobile_checks':mobile['checks'],'platform_checks':platform['checks'],'smoke':smoke,'release_checks':extra['checks'],'fixes':[{'problem':a,'change':b} for a,b in fixes],'limits':limits}
(out/'test-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
style='body{font:15px/1.85 system-ui;color:#263b35;background:#f8f5ec;max-width:1000px;margin:24px auto;padding:0 20px}h1{font-size:25px}h2{font-size:20px;margin-top:30px}p{color:#607364}a{color:#31534a}li{margin-bottom:14px}img{width:100%;border-radius:12px}figure{margin:0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:24px}code{font-size:11px;word-break:break-all}'
head=lambda title:'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>'+style+'</style>'
links='<p><a href="./?v=0.9.0">打开新版游戏</a>　<a href="art-update.html">实际游戏截图</a>　<a href="test-report.html">改动和测试记录</a></p>'
chinese=['食品分类图片加载','横划12摞整排加层','再次横划叠至第三层','满层拒绝溢出','整排一次撤销','清空普通架全部层','撤销清空精确恢复','调整层板保留库存','层板调整可撤销','短点按仅加一件','长按纵列含已有堆叠','纵列一次撤销','压缩存档重开恢复','单指镜头转动','双指平移缩放不误放','新食物跨分类搜索','小屏幕场景可操作','离线CSP无外部请求及缺图']
(out/'test-report.html').write_text(head('v0.9.0 改动与测试')+'<h1>我在末日前囤物资 · v0.9.0</h1>'+links+'<h2>这次改了什么</h2><ul>'+''.join('<li><b>'+html.escape(a)+'</b><p>'+html.escape(b)+'</p></li>' for a,b in fixes)+'</ul><h2>已通过的检查</h2><p>13组规则检查、19项触控浏览器检查、2组WebGL1及原生存储模拟检查，以及16项加载和布局检查。</p><ul>'+''.join('<li>'+html.escape(x)+'</li>' for x in chinese+['连续横划后触发准确数量提示']+[x['name'] for x in platform['checks']]+[x['name'] for x in extra['checks']])+'</ul><h2>验证范围</h2><p>'+html.escape(limits)+'</p><p><a href="xhs-candidate.zip">小红书离线候选包</a>　<a href="downloads/source.zip">运行源码</a></p><p>游戏构建SHA-256</p><code>'+sha+'</code></html>')
shots=[('v090-first.png','preview-v090.png','手机底部物品栏与整洁仓库'),('v090-overview.png','overview-v090.png','大仓库整体空间'),('v090-landscape.png','landscape-v090.png','手机横屏仍使用底部物品栏'),('v090-quip.png','quip-v090.png','横划摆放后的幽默提示'),('v090-fridge.png','fridge-v090.png','冰箱与生鲜储物')]
for source,dest,label in shots: shutil.copyfile(r/source,out/'assets'/dest)
(out/'art-update.html').write_text(head('v0.9.0 实际游戏截图')+'<h1>新版仓库 · 实际运行截图</h1>'+links+'<p>这里展示游戏浏览器截图，未使用概念图代替运行结果。192种写实食物以2.5D形式放入可操作的3D架柜，背景已恢复为整洁的大仓库。</p><div class="grid">'+''.join('<figure><img loading="lazy" src="assets/'+dest+'" alt="'+label+'"><figcaption>'+label+'</figcaption></figure>' for _,dest,label in shots)+'</div></html>')
files=[out/'index.html',out/'assets/game.js',out/'assets/boot.js',out/'assets/style.css',out/'assets/thumbs.css',out/'assets/thumbs.webp',out/'assets/THREE-LICENSE.txt',*sorted((out/'assets').glob('place-*.wav')),out/'assets/AUDIO-LICENSE.txt',*[out/'assets'/('food-'+str(i)+'.webp') for i in range(8)],out/'assets/surfaces.jpg',out/'assets/surface-normal.jpg',out/'assets/food-icons.webp']
with zipfile.ZipFile(out/'xhs-candidate.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for f in files: z.write(f,f.relative_to(out))
with zipfile.ZipFile(out/'xhs-candidate.zip') as z:
 assert z.testzip() is None and sum(n.endswith('.html') for n in z.namelist())==1
 assert z.read('assets/game.js')==(out/'assets/game.js').read_bytes()
 assert 'assets/food-icons.webp' in z.namelist()
for name in ['xhs-candidate.zip','web-offline.zip']: shutil.copyfile(out/'xhs-candidate.zip',d/name)
(d/'README.txt').write_text('我在末日前囤物资 v0.9.0\n新版为整洁暖色3D大仓库，手机横竖屏均使用底部物品栏。独立启动器、图片自动重试与存储超时保护；111条囤货提示、33段柔化摆放音效。192种写实食物、68种生活物资、15类家具。\n清空保留家具并可撤销；旧存档升级保留物品，未能放下的进入待恢复区。\n单指收纳/长按纵列/横划整排；镜头模式单指转动，双指平移缩放转向。\n食物为2.5D写实图片，家具为3D。离线候选包不是官方审核通过包，仍待真实小红书容器、Android/iOS真机验证。\n')
source=[*sorted((p/'src').glob('*.js')),*[p/'assets'/n for n in ['library.json','food-library.json']],*[p/n for n in ['package.json','package-lock.json','build.mjs','test.mjs','ART-DIRECTION.md','production/README.md','production/thumbs.cjs','generate-audio.py']],*sorted((p/'production/v080').glob('*.mjs')),*sorted((p/'production/v080').glob('*.cjs')),p/'production/v080/foods.py',p/'production/v080/foods.json',p/'production/v080/art-rects.json',Path(__file__).resolve(),*[f for f in (p/'production/v090').rglob('*') if f.is_file() and not f.name.endswith('.v080') and f.name!='prepare-release.py']]
with zipfile.ZipFile(d/'source.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for f in source: z.write(f,f.relative_to(p))
 for f in files:
  if f.name not in ['game.js','surfaces.jpg','surface-normal.jpg',*[f'food-{i}.webp' for i in range(8)]]: z.write(f,Path('dist')/f.relative_to(out))
 z.writestr('README.md','npm ci && npm run build。包含运行源码、已打包资产、测试和离线资源。原始生成PNG与Blender工程保留在工作区；常规构建无需重制图片或运行Blender。测试脚本的浏览器依赖需另装。')
js=(out/'assets/game.js').read_text()
forbidden={n:len(re.findall(pattern,js)) for n,pattern in {'worker':r'new\s+Worker\s*\(','wasm':r'WebAssembly\.','eval':r'\beval\s*\(','dynamic_function':r'new\s+Function\s*\(','fetch':r'\bfetch\s*\('}.items()}
assert not any(forbidden.values()),forbidden
release={'version':'0.9.0','runtime_files':len(files),'runtime_js_bytes':(out/'assets/game.js').stat().st_size,'boot_js_bytes':(out/'assets/boot.js').stat().st_size,'candidate_bytes':(out/'xhs-candidate.zip').stat().st_size,'checks':13+len(mobile['checks'])+len(platform['checks'])+len(extra['checks']),'sha256':sha,'forbidden_runtime_apis':forbidden}
(r/'release-v090.json').write_text(json.dumps(release,indent=2)); print(json.dumps(release))
