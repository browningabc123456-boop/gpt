import test from 'node:test';import{inflateSync}from'node:zlib';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {ITEMS,FURNITURE} from '../src/catalog.js';
import {itemSize} from '../src/sizes.js';
const library=JSON.parse(await readFile(new URL('../assets/library.json',import.meta.url),'utf8'));
test('all 120 supplied objects and 15 containers have real near/far meshes and valid packed geometry',()=>{
 const ids=ITEMS.map(p=>p.id).concat(Object.keys(FURNITURE));assert.equal(ids.length,135);
 for(const id of ids)for(const suffix of['','__far']){
  const parts=library.entries[id+suffix];assert.ok(parts?.length,id+suffix);
  for(const p of parts){assert.ok(p.vertices>0&&p.triangles>0,id);const data=inflateSync(Buffer.from(p.data,'base64')),index=inflateSync(Buffer.from(p.indices,'base64'));assert.equal(data.length,p.vertices*20,id);assert.equal(index.length,p.triangles*3*p.indexBytes,id);for(let i=0;i<index.length;i+=p.indexBytes){const n=p.indexBytes===2?index.readUInt16LE(i):index.readUInt32LE(i);assert.ok(n<p.vertices,id+' index');}assert.ok(p.min.concat(p.span).every(Number.isFinite),id+' bounds');}
  const item=ITEMS.find(p=>p.id===id);if(item){const d=itemSize(item),min=[0,1,2].map(k=>Math.min(...parts.map(p=>p.min[k]))),max=[0,1,2].map(k=>Math.max(...parts.map(p=>p.min[k]+p.span[k])));[d.w,d.h,d.d].forEach((size,k)=>assert.ok(max[k]-min[k]<=size+1e-5,id+' collision bounds'));assert.ok(Math.abs(min[1])<1e-5,id+' sits on shelf');}
 }
 assert.ok(library.atlas.startsWith('data:image/jpeg;base64,'));assert.ok(library.normal.startsWith('data:image/jpeg;base64,'));
});
