import './production/v080/rules.test.mjs';

import './production/v090/quips.test.mjs';
