"""Build short, softened contact sounds from Kenney CC0 foley. No oscillator tones."""
import subprocess,wave,struct,math,json
from pathlib import Path
root=Path(__file__).parent; source=root/'production/v090/foley';out=root/'dist/assets'
# Family-specific damping: high rings are shortened, the initial contact remains.
recipes={'glass':('impactGlass_light',2100,.28),'metal':('impactMetal_light',1650,.24),'paper':('impactSoft_medium',1800,.30),'soft':('impactSoft_medium',1200,.25),'plastic':('impactGeneric_light',1900,.22),'fabric':('impactSoft_medium',1000,.28),'wood':('impactWood_light',1900,.26),'ceramic':('impactGlass_light',1500,.25),'lift':('impactSoft_medium',1300,.20),'complete':('impactWood_light',1300,.20),'furniture':('impactWood_light',1000,.34)}
report=[]
for family,(kind,cutoff,duration) in recipes.items():
 for variant in range(3):
  src=source/f'{kind}_{variant:03}.ogg';name=f'place-{family}-{variant}.wav'
  filters=f'highpass=f=65,lowpass=f={cutoff}:p=2,silenceremove=start_periods=1:start_duration=0.002:start_threshold=-52dB,atrim=0:{duration},afade=t=in:d=0.0025,afade=t=out:st={duration-.08}:d=0.08'
  raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(src),'-af',filters,'-ar','22050','-ac','1','-f','s16le','-'])
  samples=list(struct.unpack('<'+'h'*(len(raw)//2),raw));peak=max(abs(x) for x in samples) or 1
  target=.25 if family not in ['complete','lift'] else .15
  gain=min(2,target*32767/peak);samples=[max(-32767,min(32767,round(x*gain))) for x in samples]
  # Fade the actual tail as source takes sometimes end before the trim limit.
  fade=min(int(.045*22050),len(samples)//3)
  for j in range(fade): samples[-1-j]=round(samples[-1-j]*j/max(1,fade))
  with wave.open(str(out/name),'wb') as w:w.setparams((1,2,22050,0,'NONE','not compressed'));w.writeframes(struct.pack('<'+'h'*len(samples),*samples))
  report.append({'file':name,'source':src.name,'cutoff_hz':cutoff,'seconds':len(samples)/22050,'peak':max(abs(x) for x in samples)/32768,'rms':math.sqrt(sum(x*x for x in samples)/len(samples))/32768})
license_text=(source/'kenney-impact-sounds-license.txt').read_text()
(out/'AUDIO-LICENSE.txt').write_text(license_text+'\nModified for the warehouse game: low/high pass filtering, fades, level matching and short tails.\nSource: https://kenney.nl/assets/impact-sounds\nMirror: https://github.com/GeorgeQLe/assets-sfx-combat\n')
(root/'results/audio-v090.json').write_text(json.dumps(report,indent=2));print('Built',len(report),'soft contact clips; peak <=',max(x['peak'] for x in report))
